# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "SakugaGP",
    "author" : "Sadewoo", 
    "description" : "Addon for Grease Pencil v3 for 2D Animators",
    "blender" : (4, 3, 0),
    "version" : (1, 1, 4),
    "location" : "",
    "warning" : "",
    "doc_url": "https://spikysaurus.github.io/", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
import bpy,bmesh
import  bpy
import bpy, webbrowser
import os
import bpy,os




def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items[value].value
    return string_to_int(value)


addon_keymaps = {}
_icons = None
tools = {'sna_is_greasepencil': False, }
camera = {'sna_check_camera': False, }
menu = {'sna_check_rotate': False, }
selector = {'sna_default_opacity': 0.30000001192092896, 'sna_opacity_mesh_check': False, 'sna_opacity_gp_check': False, 'sna_opacity_ref_check': False, }


def sna_update_sna_brush_size_E295A(self, context):
    sna_updated_prop = self.sna_brush_size
    val = sna_updated_prop
    calc = val/400
    bpy.context.tool_settings.gpencil_paint.brush.unprojected_radius = calc


def sna_update_sna_rotation_slider_BF78B(self, context):
    sna_updated_prop = self.sna_rotation_slider
    bpy.data.objects[str(bpy.context.scene.camera.name)].rotation_euler.y = bpy.context.scene.sna_rotation_slider


def sna_update_sna_mute_camera_action_27A28(self, context):
    sna_updated_prop = self.sna_mute_camera_action
    bool = sna_updated_prop
    active = bpy.context.scene.camera
    action = active.animation_data.action
    for i in action.fcurves:
        i.mute = bool
        bpy.context.scene.render.fps


def sna_update_sna_object_list_EDFF0(self, context):
    sna_updated_prop = self.sna_object_list
    bpy.context.view_layer.objects.active = bpy.data.objects[sna_updated_prop]
    bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='OBJECT')
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'OUTLINER'
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.area.type = prev_context
    bpy.data.objects[sna_updated_prop].select_set(state=True, )


def sna_update_sna_opacity_ref_6D10B(self, context):
    sna_updated_prop = self.sna_opacity_ref
    bpy.context.view_layer.objects.active.color[3] = sna_updated_prop


def sna_update_sna_opacity_mesh_E925E(self, context):
    sna_updated_prop = self.sna_opacity_mesh
    bpy.context.view_layer.objects.active.active_material.node_tree.nodes['sakugagp_opacity'].inputs[1].default_value = sna_updated_prop


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_FECBF(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_FECBF, icon, active_data, active_propname, index_FECBF):
        row = layout
        row_186E9 = layout.row(heading='', align=False)
        row_186E9.alert = False
        row_186E9.enabled = True
        row_186E9.active = True
        row_186E9.use_property_split = False
        row_186E9.use_property_decorate = False
        row_186E9.scale_x = 1.0
        row_186E9.scale_y = 1.0
        row_186E9.alignment = 'Expand'.upper()
        row_186E9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if item_FECBF.type == 'MESH':
            row_186E9.label(text='', icon_value=string_to_icon('OUTLINER_OB_MESH'))
        else:
            row_186E9.label(text='', icon_value=string_to_icon('OUTLINER_OB_GREASEPENCIL'))
        row_186E9.prop(item_FECBF, 'name', text='', icon_value=0, emboss=False)
        row_7915F = layout.row(heading='', align=True)
        row_7915F.alert = False
        row_7915F.enabled = True
        row_7915F.active = True
        row_7915F.use_property_split = False
        row_7915F.use_property_decorate = False
        row_7915F.scale_x = 1.0
        row_7915F.scale_y = 1.0
        row_7915F.alignment = 'Left'.upper()
        row_7915F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_7915F.label(text=str(int(bpy.data.objects[str(item_FECBF.name)].location.y * 1000.0)), icon_value=0)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if sna_filter_gp_2AA1B(item):
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def sna_update_sna_hide_all_B8EB4(self, context):
    sna_updated_prop = self.sna_hide_all
    if sna_updated_prop:
        bpy.context.scene.sna_hide_tools = True
        bpy.context.scene.sna_hide_camera = True
        bpy.context.scene.sna_hide_copas = True
        bpy.context.scene.sna_hide_strokes = True
        bpy.context.scene.sna_hide_object = True
    else:
        bpy.context.scene.sna_hide_tools = False
        bpy.context.scene.sna_hide_camera = False
        bpy.context.scene.sna_hide_copas = False
        bpy.context.scene.sna_hide_strokes = False


def sna_add_to_view3d_pt_tools_active_2E5D2(self, context):
    if not (bpy.context.scene.sna_hide_strokes):
        layout = self.layout
        if (tools['sna_is_greasepencil'] or False):
            box_D3836 = layout.box()
            box_D3836.alert = False
            box_D3836.enabled = True
            box_D3836.active = True
            box_D3836.use_property_split = False
            box_D3836.use_property_decorate = False
            box_D3836.alignment = 'Expand'.upper()
            box_D3836.scale_x = 1.0
            box_D3836.scale_y = 1.0
            if not True: box_D3836.operator_context = "EXEC_DEFAULT"
            box_D3836.label(text='Strokes', icon_value=string_to_icon('STROKE'))
            col_8253B = box_D3836.column(heading='', align=True)
            col_8253B.alert = False
            col_8253B.enabled = True
            col_8253B.active = True
            col_8253B.use_property_split = False
            col_8253B.use_property_decorate = False
            col_8253B.scale_x = 1.2000000476837158
            col_8253B.scale_y = 1.2000000476837158
            col_8253B.alignment = 'Expand'.upper()
            col_8253B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            grid_1A72F = col_8253B.grid_flow(columns=0, row_major=False, even_columns=False, even_rows=False, align=True)
            grid_1A72F.enabled = True
            grid_1A72F.active = True
            grid_1A72F.use_property_split = False
            grid_1A72F.use_property_decorate = False
            grid_1A72F.alignment = 'Expand'.upper()
            grid_1A72F.scale_x = 1.2000000476837158
            grid_1A72F.scale_y = 1.2000000476837158
            if not True: grid_1A72F.operator_context = "EXEC_DEFAULT"
            op = grid_1A72F.operator('grease_pencil.reorder', text='', icon_value=string_to_icon('TRIA_UP'), emboss=True, depress=False)
            op.direction = 'TOP'
            op = grid_1A72F.operator('grease_pencil.reorder', text='', icon_value=string_to_icon('TRIA_DOWN'), emboss=True, depress=False)
            op.direction = 'BOTTOM'
            row_BD173 = col_8253B.row(heading='', align=True)
            row_BD173.alert = False
            row_BD173.enabled = True
            row_BD173.active = True
            row_BD173.use_property_split = False
            row_BD173.use_property_decorate = False
            row_BD173.scale_x = 1.0
            row_BD173.scale_y = 1.0
            row_BD173.alignment = 'Expand'.upper()
            row_BD173.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_BD173.operator('wm.flip_x_a8e72', text='X', icon_value=0, emboss=True, depress=False)
            op = row_BD173.operator('wm.flip_y_8d615', text='Y', icon_value=0, emboss=True, depress=False)
            grid_6D1A7 = col_8253B.grid_flow(columns=0, row_major=False, even_columns=False, even_rows=False, align=True)
            grid_6D1A7.enabled = True
            grid_6D1A7.active = True
            grid_6D1A7.use_property_split = False
            grid_6D1A7.use_property_decorate = False
            grid_6D1A7.alignment = 'Expand'.upper()
            grid_6D1A7.scale_x = 1.2000000476837158
            grid_6D1A7.scale_y = 1.2000000476837158
            if not True: grid_6D1A7.operator_context = "EXEC_DEFAULT"
            op = grid_6D1A7.operator('wm.split_7a0de', text='', icon_value=string_to_icon('PARTICLE_TIP'), emboss=True, depress=False)
            op = grid_6D1A7.operator('wm.transform_strokes_a04ca', text='', icon_value=string_to_icon('EMPTY_ARROWS'), emboss=True, depress=False)


class SNA_OT_Flip_X_A8E72(bpy.types.Operator):
    bl_idname = "wm.flip_x_a8e72"
    bl_label = "Flip X"
    bl_description = "Flip selected Strokes horizontally"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.transform.mirror(orient_type='GLOBAL', constraint_axis=(True, False, False))")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Flip_Y_8D615(bpy.types.Operator):
    bl_idname = "wm.flip_y_8d615"
    bl_label = "Flip Y"
    bl_description = "Flip selected Strokes vertically"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.transform.mirror(orient_type='GLOBAL', constraint_axis=(False, False, True))")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Strokes_A04Ca(bpy.types.Operator):
    bl_idname = "wm.transform_strokes_a04ca"
    bl_label = "Transform Strokes"
    bl_description = "Transform selected Strokes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='EDIT')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.transform")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Split_7A0De(bpy.types.Operator):
    bl_idname = "wm.split_7a0de"
    bl_label = "Split"
    bl_description = "Separating selected points (GPv2 feature that was removed in GPv3)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.grease_pencil.duplicate('INVOKE_DEFAULT', )

        def delayed_31FBA():
            bpy.ops.grease_pencil.copy('INVOKE_DEFAULT', )

            def delayed_D0F6D():
                bpy.ops.ed.undo('INVOKE_DEFAULT', )

                def delayed_2EF1E():
                    bpy.ops.grease_pencil.delete('INVOKE_DEFAULT', )

                    def delayed_5FA3F():
                        bpy.ops.grease_pencil.paste('INVOKE_DEFAULT', )
                    bpy.app.timers.register(delayed_5FA3F, first_interval=0.0010000000474974513)
                bpy.app.timers.register(delayed_2EF1E, first_interval=0.0010000000474974513)
            bpy.app.timers.register(delayed_D0F6D, first_interval=0.0010000000474974513)
        bpy.app.timers.register(delayed_31FBA, first_interval=0.0010000000474974513)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_pt_tools_active_13B73(self, context):
    if not (bpy.context.scene.sna_hide_tools):
        layout = self.layout
        if tools['sna_is_greasepencil']:
            box_8F104 = layout.box()
            box_8F104.alert = False
            box_8F104.enabled = True
            box_8F104.active = True
            box_8F104.use_property_split = False
            box_8F104.use_property_decorate = False
            box_8F104.alignment = 'Expand'.upper()
            box_8F104.scale_x = 1.0
            box_8F104.scale_y = 1.0
            if not True: box_8F104.operator_context = "EXEC_DEFAULT"
            box_8F104.label(text='Tools', icon_value=string_to_icon('TOOL_SETTINGS'))
            col_E908F = box_8F104.column(heading='', align=True)
            col_E908F.alert = False
            col_E908F.enabled = True
            col_E908F.active = True
            col_E908F.use_property_split = False
            col_E908F.use_property_decorate = False
            col_E908F.scale_x = 1.0
            col_E908F.scale_y = 1.0
            col_E908F.alignment = 'Expand'.upper()
            col_E908F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            if bpy.context.scene.sna_show_brush_size_converter_pixel_to_meter:
                col_E908F.prop(bpy.context.scene, 'sna_brush_size', text='', icon_value=0, emboss=True)
            grid_5DFC5 = col_E908F.grid_flow(columns=0, row_major=False, even_columns=False, even_rows=False, align=True)
            grid_5DFC5.enabled = True
            grid_5DFC5.active = True
            grid_5DFC5.use_property_split = False
            grid_5DFC5.use_property_decorate = False
            grid_5DFC5.alignment = 'Expand'.upper()
            grid_5DFC5.scale_x = 1.2000000476837158
            grid_5DFC5.scale_y = 1.2000000476837158
            if not True: grid_5DFC5.operator_context = "EXEC_DEFAULT"
            op = grid_5DFC5.operator('wm.lasso_cf183', text='', icon_value=string_to_icon('RESTRICT_SELECT_OFF'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.brush_57d3a', text='', icon_value=string_to_icon('GREASEPENCIL'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.erase_9d8e8', text='', icon_value=string_to_icon('META_CAPSULE'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.fill_88837', text='', icon_value=string_to_icon('IMAGE'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.sculpt_bbd1c', text='', icon_value=string_to_icon('MOD_WARP'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.line_a9a17', text='', icon_value=string_to_icon('IPO_LINEAR'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.trim_9d5fa', text='', icon_value=string_to_icon('MOD_OFFSET'), emboss=True, depress=False)
            op = grid_5DFC5.operator('wm.transform_object_ab8d4', text='', icon_value=string_to_icon('OBJECT_ORIGIN'), emboss=True, depress=False)


@persistent
def depsgraph_update_pre_handler_B3A42(dummy):
    x = None
    count = len(bpy.context.selected_objects)
    if count > 0:
        if bpy.context.object.type == 'GREASEPENCIL':
            x = True
        else:
            x = False
    else:
        x = False
    tools['sna_is_greasepencil'] = x


class SNA_OT_Lasso_Cf183(bpy.types.Operator):
    bl_idname = "wm.lasso_cf183"
    bl_label = "Lasso"
    bl_description = "Lasso tool for selecting Strokes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='EDIT')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.select_lasso")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Brush_57D3A(bpy.types.Operator):
    bl_idname = "wm.brush_57d3a"
    bl_label = "Brush"
    bl_description = "Hold ctrl to erase, change the default eraser in Properties > Tool > Eraser"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.brush")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Erase_9D8E8(bpy.types.Operator):
    bl_idname = "wm.erase_9d8e8"
    bl_label = "Erase"
    bl_description = "Erase past your mistakes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin_brush.Erase")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Fill_88837(bpy.types.Operator):
    bl_idname = "wm.fill_88837"
    bl_label = "Fill"
    bl_description = "Properties > Tool > Brush > Settings > Advanced > Gap Closure > Uncheck Visual Aids to disable double click to fill"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin_brush.Fill")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Line_A9A17(bpy.types.Operator):
    bl_idname = "wm.line_a9a17"
    bl_label = "Line"
    bl_description = "Draw a line"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.line")')
        exec('')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Sculpt_Bbd1C(bpy.types.Operator):
    bl_idname = "wm.sculpt_bbd1c"
    bl_label = "Sculpt"
    bl_description = "Enter Sculpt Mode"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='SCULPT_GREASE_PENCIL')")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Gradient_6A423(bpy.types.Operator):
    bl_idname = "wm.gradient_6a423"
    bl_label = "Gradient"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='EDIT')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.texture_gradient")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Trim_9D5Fa(bpy.types.Operator):
    bl_idname = "wm.trim_9d5fa"
    bl_label = "Trim"
    bl_description = "Delete stroke points in between intersecting strokes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.trim")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Draw_Camera_Guide_B1399(bpy.types.Operator):
    bl_idname = "wm.draw_camera_guide_b1399"
    bl_label = "Draw Camera Guide"
    bl_description = "Draw the outline of active Camera"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.active_object.type == 'GREASEPENCIL':
            obj_arr = []
            mat_arr = []
            target = bpy.context.active_object
            target_mat = target.active_material
            obj_arr.append(target)
            mat_arr.append(target_mat)
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.mesh.primitive_plane_add()
            newplane = bpy.context.selected_objects[0]
            newplane.name = "C4MGUIDE"
            newplane.data.name = newplane.name
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.delete()

            def view3d_find():
                for area in bpy.context.window.screen.areas:
                    if area.type == 'VIEW_3D':
                        v3d = area.spaces[0]
                        rv3d = v3d.region_3d
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                return region, rv3d
                return None, None

            def view3d_camera_border(scene):
                obj = scene.camera
                cam = obj.data
                frame = cam.view_frame(scene=scene)
                frame_px = [obj.matrix_world @ v for v in frame]
                return frame_px
            frame_px = view3d_camera_border(bpy.context.scene)
            areas  = [area for area in bpy.context.window.screen.areas if area.type == 'VIEW_3D']
            with bpy.context.temp_override(
                window=bpy.context.window,
                area=areas[0],
                region=[region for region in areas[0].regions if region.type == 'WINDOW'][0],
                screen=bpy.context.window.screen
            ):
                for area in bpy.context.screen.areas:
                    if area.type == 'VIEW_3D':
                        bpy.ops.view3d.snap_cursor_to_center()
                        obj = bpy.context.object
                        me = obj.data
                        bm = bmesh.from_edit_mesh(me)
                        v1 = bm.verts.new((frame_px[0]))
                        v2 = bm.verts.new((frame_px[1]))
                        v3 = bm.verts.new((frame_px[2]))
                        v4 = bm.verts.new((frame_px[3]))
                        bm.edges.new((v1, v2))
                        bm.edges.new((v2, v3))
                        bm.edges.new((v3, v4))
                        bm.edges.new((v4, v1))
                        bmesh.update_edit_mesh(obj.data)
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.convert(target='CURVE',keep_original=False)
                        bpy.ops.object.convert(target='GREASEPENCIL',keep_original=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        res = [k for k in obj.material_slots]
                        for mat in bpy.data.materials:
                            if mat.is_grease_pencil and mat.name == mat_arr[0].name:
                                obj.data.materials.append(mat)
                        bpy.ops.grease_pencil.select_all(action='SELECT')        
                        bpy.ops.grease_pencil.reproject(type='VIEW')
                        bpy.ops.grease_pencil.set_uniform_thickness(thickness=0.02)
                        bpy.ops.grease_pencil.set_uniform_opacity(opacity_stroke=1.0, opacity_fill=1.0)
                        bpy.ops.grease_pencil.copy()
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.delete(use_global=False)
                        bpy.context.view_layer.objects.active = obj_arr[0]
                        bpy.context.view_layer.objects.active.select_set(True)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.grease_pencil.paste(type='ACTIVE')
                        bpy.ops.outliner.orphans_purge()
        else: pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Object_Ab8D4(bpy.types.Operator):
    bl_idname = "wm.transform_object_ab8d4"
    bl_label = "Transform Object"
    bl_description = "Transform selected object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.mode_set(mode='OBJECT')")
        exec('bpy.ops.wm.tool_set_by_id(name="builtin.transform")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_pt_tools_active_EDA18(self, context):
    if not (bpy.context.scene.sna_hide_copas):
        layout = self.layout
        if tools['sna_is_greasepencil']:
            box_8F2A8 = layout.box()
            box_8F2A8.alert = False
            box_8F2A8.enabled = True
            box_8F2A8.active = True
            box_8F2A8.use_property_split = False
            box_8F2A8.use_property_decorate = False
            box_8F2A8.alignment = 'Expand'.upper()
            box_8F2A8.scale_x = 1.0
            box_8F2A8.scale_y = 1.0
            if not True: box_8F2A8.operator_context = "EXEC_DEFAULT"
            box_8F2A8.label(text='Copas', icon_value=string_to_icon('DUPLICATE'))
            grid_0292E = box_8F2A8.grid_flow(columns=0, row_major=False, even_columns=False, even_rows=False, align=True)
            grid_0292E.enabled = True
            grid_0292E.active = True
            grid_0292E.use_property_split = False
            grid_0292E.use_property_decorate = False
            grid_0292E.alignment = 'Expand'.upper()
            grid_0292E.scale_x = 1.2000000476837158
            grid_0292E.scale_y = 1.2000000476837158
            if not True: grid_0292E.operator_context = "EXEC_DEFAULT"
            op = grid_0292E.operator('wm.cut_50749', text='', icon_value=string_to_icon('NODE_INSERT_OFF'), emboss=True, depress=False)
            op = grid_0292E.operator('grease_pencil.copy', text='', icon_value=string_to_icon('DUPLICATE'), emboss=True, depress=False)
            op = grid_0292E.operator('grease_pencil.paste', text='', icon_value=string_to_icon('FILE'), emboss=True, depress=False)
            op = grid_0292E.operator('grease_pencil.delete', text='', icon_value=string_to_icon('TRASH'), emboss=True, depress=False)


class SNA_OT_Cut_50749(bpy.types.Operator):
    bl_idname = "wm.cut_50749"
    bl_label = "Cut"
    bl_description = "Cut selected strokes or points"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.grease_pencil.copy('INVOKE_DEFAULT', )
        bpy.ops.grease_pencil.delete('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_pt_tools_active_679FF(self, context):
    if not ((bpy.context.scene.sna_hide_camera or camera['sna_check_camera'])):
        layout = self.layout
        if True:
            box_FF417 = layout.box()
            box_FF417.alert = False
            box_FF417.enabled = True
            box_FF417.active = True
            box_FF417.use_property_split = False
            box_FF417.use_property_decorate = False
            box_FF417.alignment = 'Expand'.upper()
            box_FF417.scale_x = 1.0
            box_FF417.scale_y = 1.0
            if not True: box_FF417.operator_context = "EXEC_DEFAULT"
            op = box_FF417.operator('wm.select_active_camera_81ec7', text='Camera', icon_value=string_to_icon('CAMERA_DATA'), emboss=False, depress=False)
            col_95FB8 = box_FF417.column(heading='', align=True)
            col_95FB8.alert = False
            col_95FB8.enabled = True
            col_95FB8.active = True
            col_95FB8.use_property_split = False
            col_95FB8.use_property_decorate = False
            col_95FB8.scale_x = 1.0
            col_95FB8.scale_y = 1.0
            col_95FB8.alignment = 'Expand'.upper()
            col_95FB8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_380B8 = col_95FB8.row(heading='', align=True)
            row_380B8.alert = False
            row_380B8.enabled = True
            row_380B8.active = True
            row_380B8.use_property_split = False
            row_380B8.use_property_decorate = False
            row_380B8.scale_x = 1.0
            row_380B8.scale_y = 1.0
            row_380B8.alignment = 'Expand'.upper()
            row_380B8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_380B8.prop(bpy.context.scene.camera.data, 'show_passepartout', text='', icon_value=string_to_icon('OUTLINER_OB_CAMERA'), emboss=True)
            row_380B8.prop(bpy.context.scene.camera.data, 'passepartout_alpha', text='', icon_value=0, emboss=True)
            row_BFED7 = col_95FB8.row(heading='', align=True)
            row_BFED7.alert = False
            row_BFED7.enabled = True
            row_BFED7.active = True
            row_BFED7.use_property_split = False
            row_BFED7.use_property_decorate = False
            row_BFED7.scale_x = 1.0
            row_BFED7.scale_y = 1.0
            row_BFED7.alignment = 'Expand'.upper()
            row_BFED7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_BFED7.operator('wm.reset_camera_rotation_02dbe', text='', icon_value=string_to_icon('LOOP_BACK'), emboss=True, depress=False)
            row_BFED7.prop(bpy.context.scene, 'sna_rotation_slider', text='', icon_value=0, emboss=True)
            grid_BA00D = col_95FB8.grid_flow(columns=2, row_major=False, even_columns=False, even_rows=False, align=True)
            grid_BA00D.enabled = True
            grid_BA00D.active = True
            grid_BA00D.use_property_split = False
            grid_BA00D.use_property_decorate = False
            grid_BA00D.alignment = 'Expand'.upper()
            grid_BA00D.scale_x = 1.0
            grid_BA00D.scale_y = 1.0
            if not True: grid_BA00D.operator_context = "EXEC_DEFAULT"
            grid_BA00D.prop(bpy.context.scene, 'sna_mute_camera_action', text='', icon_value=string_to_icon('DECORATE_LOCKED'), emboss=True)
            op = grid_BA00D.operator('wm.mirror_camera_horizontally_861b9', text='X', icon_value=0, emboss=True, depress=False)
            if tools['sna_is_greasepencil']:
                op = grid_BA00D.operator('wm.draw_camera_guide_b1399', text='', icon_value=string_to_icon('SELECT_SET'), emboss=True, depress=False)
            else:
                op = grid_BA00D.operator('sn.dummy_button_operator', text='', icon_value=string_to_icon('SELECT_SET'), emboss=False, depress=False)
            op = grid_BA00D.operator('wm.mirror_camera_vertically_1fff5', text='Y', icon_value=0, emboss=True, depress=False)


@persistent
def depsgraph_update_pre_handler_172E3(dummy):
    cam = bpy.context.scene.camera.data
    x = None
    if cam is not None:
        x = False
    else:
        x = True
    camera['sna_check_camera'] = x


class SNA_OT_Select_Active_Camera_81Ec7(bpy.types.Operator):
    bl_idname = "wm.select_active_camera_81ec7"
    bl_label = "Select Active Camera"
    bl_description = "Select the Active Camera for current scene (Scene Properties > Camera)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active = bpy.context.scene.camera
        bpy.ops.object.mode_set(mode='OBJECT')
        for i in bpy.data.objects:
            i.select_set(False)
        bpy.context.scene.camera.select_set(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mirror_Camera_Horizontally_861B9(bpy.types.Operator):
    bl_idname = "wm.mirror_camera_horizontally_861b9"
    bl_label = "Mirror Camera Horizontally"
    bl_description = "Invert X Scale"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        cam = bpy.context.scene.camera
        #bpy.ops.view3d.view_center_cursor()
        if cam.scale.x == 1.0:
            cam.scale.x = -1.0
        else :
            cam.scale.x = 1.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mirror_Camera_Vertically_1Fff5(bpy.types.Operator):
    bl_idname = "wm.mirror_camera_vertically_1fff5"
    bl_label = "Mirror Camera Vertically"
    bl_description = "Invert Y Scale"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        cam = bpy.context.scene.camera
        if cam.scale.y == 1.0:
            cam.scale.y = -1.0
        else :
            cam.scale.y = 1.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Camera_Rotation_02Dbe(bpy.types.Operator):
    bl_idname = "wm.reset_camera_rotation_02dbe"
    bl_label = "Reset Camera Rotation"
    bl_description = "Reset Camera Rotation to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_rotation_slider = 0.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Empty_Without_Materials_7097F(bpy.types.Operator):
    bl_idname = "wm.add_empty_without_materials_7097f"
    bl_label = "Add Empty without Materials"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.active_object is None :
            bpy.ops.object.grease_pencil_add(type='EMPTY',use_lights=False)
            bpy.data.grease_pencils_v3[bpy.context.active_object.data.name].use_autolock_layers = True
        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.grease_pencil_add(type='EMPTY',use_lights=False)
            bpy.data.grease_pencils_v3[bpy.context.active_object.data.name].use_autolock_layers = True
        obj = bpy.context.object
        if obj is not None:
            if obj.type == 'GREASEPENCIL':
                if obj.active_material is not None:
                    bpy.data.materials.remove(obj.active_material)
                    bpy.ops.object.material_slot_remove()
                else: pass
            else: pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Empty_With_All_Materials_Abd31(bpy.types.Operator):
    bl_idname = "wm.add_empty_with_all_materials_abd31"
    bl_label = "Add Empty with all Materials"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.active_object is None :
            bpy.ops.object.grease_pencil_add(type='EMPTY',use_lights=False)
            bpy.data.grease_pencils_v3[bpy.context.active_object.data.name].use_autolock_layers = True
        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.grease_pencil_add(type='EMPTY',use_lights=False)
            bpy.data.grease_pencils_v3[bpy.context.active_object.data.name].use_autolock_layers = True
        obj = bpy.context.object
        if obj is not None:
            if obj.type == 'GREASEPENCIL':
                if obj.active_material is not None:
                    bpy.data.materials.remove(obj.active_material)
                    bpy.ops.object.material_slot_remove()
                else: pass
            else: pass
        obj = bpy.context.object
        arr_x = [x.name for x in obj.material_slots]
        res = [k for k in obj.material_slots]

        def app():
            for mat in bpy.data.materials:
                if mat.is_grease_pencil and mat.name not in arr_x:
                    obj.data.materials.append(mat)

        def rem():
            for slot in res:
                if slot.material is None:
                    # Set the active material slot to Empty
                    obj.active_material_index = slot.slot_index
                    # Remove the active material slot
                    bpy.ops.object.material_slot_remove()
                else: pass
        rem()
        app()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_GREASE_PENCIL_D473A(bpy.types.Panel):
    bl_label = 'Grease Pencil'
    bl_idname = 'SNA_PT_GREASE_PENCIL_D473A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'SakugaGP'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_INFO_2DE4D(bpy.types.Panel):
    bl_label = 'Info'
    bl_idname = 'SNA_PT_INFO_2DE4D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 4
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_4F668 = layout.column(heading='', align=False)
        col_4F668.alert = False
        col_4F668.enabled = True
        col_4F668.active = True
        col_4F668.use_property_split = False
        col_4F668.use_property_decorate = False
        col_4F668.scale_x = 1.0
        col_4F668.scale_y = 1.0
        col_4F668.alignment = 'Expand'.upper()
        col_4F668.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_34616 = col_4F668.box()
        box_34616.alert = False
        box_34616.enabled = True
        box_34616.active = True
        box_34616.use_property_split = False
        box_34616.use_property_decorate = False
        box_34616.alignment = 'Expand'.upper()
        box_34616.scale_x = 1.0
        box_34616.scale_y = 1.0
        if not True: box_34616.operator_context = "EXEC_DEFAULT"
        col_130A7 = box_34616.column(heading='', align=True)
        col_130A7.alert = False
        col_130A7.enabled = True
        col_130A7.active = True
        col_130A7.use_property_split = False
        col_130A7.use_property_decorate = False
        col_130A7.scale_x = 1.0
        col_130A7.scale_y = 1.0
        col_130A7.alignment = 'Expand'.upper()
        col_130A7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_130A7.label(text='My website and links :', icon_value=0)
        op = col_130A7.operator('wm.my_website_2d6bd', text='My Website', icon_value=string_to_icon('URL'), emboss=True, depress=False)
        op = col_130A7.operator('wm.gumroad_fe695', text='SakugaGP', icon_value=string_to_icon('URL'), emboss=True, depress=False)
        box_611C5 = col_4F668.box()
        box_611C5.alert = False
        box_611C5.enabled = True
        box_611C5.active = True
        box_611C5.use_property_split = False
        box_611C5.use_property_decorate = False
        box_611C5.alignment = 'Expand'.upper()
        box_611C5.scale_x = 1.0
        box_611C5.scale_y = 1.0
        if not True: box_611C5.operator_context = "EXEC_DEFAULT"
        col_6B754 = box_611C5.column(heading='', align=True)
        col_6B754.alert = False
        col_6B754.enabled = True
        col_6B754.active = True
        col_6B754.use_property_split = False
        col_6B754.use_property_decorate = False
        col_6B754.scale_x = 1.0
        col_6B754.scale_y = 1.0
        col_6B754.alignment = 'Expand'.upper()
        col_6B754.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_6B754.label(text='Recommended Addons :', icon_value=string_to_icon('URL'))
        op = col_6B754.operator('wm.nijigpen_c9163', text='NijiGPen', icon_value=string_to_icon('URL'), emboss=True, depress=False)
        op = col_6B754.operator('wm.camera_overscan_fee71', text='Camera Overscan', icon_value=string_to_icon('URL'), emboss=True, depress=False)


class SNA_OT_Nijigpen_C9163(bpy.types.Operator):
    bl_idname = "wm.nijigpen_c9163"
    bl_label = "NijiGPen"
    bl_description = "I'm using it mainly for cleanup, but it can do a lot things for Grease Pencil"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        webbrowser.open('https://github.com/chsh2/nijiGPen')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Camera_Overscan_Fee71(bpy.types.Operator):
    bl_idname = "wm.camera_overscan_fee71"
    bl_label = "Camera Overscan"
    bl_description = "For canvas resizing (Expand/Crop the Camera)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        webbrowser.open('https://projects.blender.org/pioverfour/camera_overscan')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Website_2D6Bd(bpy.types.Operator):
    bl_idname = "wm.my_website_2d6bd"
    bl_label = "My Website"
    bl_description = "My Art and Animations are here!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        webbrowser.open('https://spikysaurus.github.io')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Gumroad_Fe695(bpy.types.Operator):
    bl_idname = "wm.gumroad_fe695"
    bl_label = "Gumroad"
    bl_description = "Visit Gumroad"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        webbrowser.open('https://sadewoo.gumroad.com/l/SakugaGP')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Link_All_Materials_A41Fe(bpy.types.Operator):
    bl_idname = "wm.link_all_materials_a41fe"
    bl_label = "Link All Materials"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj = bpy.context.object
        arr_x = [x.name for x in obj.material_slots]
        res = [k for k in obj.material_slots]

        def app():
            for mat in bpy.data.materials:
                if mat.is_grease_pencil and mat.name not in arr_x:
                    obj.data.materials.append(mat)

        def rem():
            for slot in res:
                if slot.material is None:
                    # Set the active material slot to Empty
                    obj.active_material_index = slot.slot_index
                    # Remove the active material slot
                    bpy.ops.object.material_slot_remove()
                else: pass
        rem()
        app()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Unlink_All_Materials_7Fc01(bpy.types.Operator):
    bl_idname = "wm.unlink_all_materials_7fc01"
    bl_label = "Unlink All Materials"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj = bpy.context.active_object
        last = len(obj.material_slots)
        res = [k for k in obj.material_slots]

        def remove():
            obj.active_material_index = last
            bpy.ops.object.material_slot_remove()   
        for slot in res:
            remove()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Delete_Material_238Fa(bpy.types.Operator):
    bl_idname = "wm.delete_material_238fa"
    bl_label = "Delete Material"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj = bpy.context.object
        if obj is not None:
            if obj.type == 'GREASEPENCIL':
                if obj.active_material is not None:
                    bpy.data.materials.remove(obj.active_material)
                    bpy.ops.object.material_slot_remove()
                else: pass
            else: pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Material_Stroke_Only_S_F198A(bpy.types.Operator):
    bl_idname = "wm.add_material_stroke_only_s_f198a"
    bl_label = "Add Material Stroke Only (S)"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        ob = bpy.context.active_object
        mat = bpy.data.materials.new(name="S-")
        bpy.data.materials.create_gpencil_data(mat)
        ob.data.materials.append(mat)
        mat.grease_pencil.show_stroke = True
        mat.grease_pencil.show_fill = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Material_Fill_Only_F_B7E95(bpy.types.Operator):
    bl_idname = "wm.add_material_fill_only_f_b7e95"
    bl_label = "Add Material Fill Only (F)"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        ob = bpy.context.active_object
        mat = bpy.data.materials.new(name="F-")
        bpy.data.materials.create_gpencil_data(mat)
        ob.data.materials.append(mat)
        mat.grease_pencil.show_stroke = False
        mat.grease_pencil.show_fill = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Material_Stroke_And_Fill_B_B_For_Both_581B7(bpy.types.Operator):
    bl_idname = "wm.add_material_stroke_and_fill_b_b_for_both_581b7"
    bl_label = "Add Material Stroke and Fill (B) B for Both"
    bl_description = "Add Material Stroke and Fill (B)(B for Both)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        ob = bpy.context.active_object
        mat = bpy.data.materials.new(name="B-")
        bpy.data.materials.create_gpencil_data(mat)
        ob.data.materials.append(mat)
        mat.grease_pencil.show_stroke = True
        mat.grease_pencil.show_fill = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_menu_7280E(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_menu_7280E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'SakugaGP'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.popover('SNA_PT_INFO_2DE4D', text='SakugaGP v1.1.4', icon_value=string_to_icon('INFO'))

    def draw(self, context):
        layout = self.layout
        row_84FB5 = layout.row(heading='', align=True)
        row_84FB5.alert = False
        row_84FB5.enabled = True
        row_84FB5.active = True
        row_84FB5.use_property_split = False
        row_84FB5.use_property_decorate = False
        row_84FB5.scale_x = 1.0
        row_84FB5.scale_y = 1.0
        row_84FB5.alignment = 'Expand'.upper()
        row_84FB5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_84FB5.popover('SNA_PT_RENDER_AND_EXPORT_6F5DF', text='Render', icon_value=0)
        row_84FB5.popover('SNA_PT_SETTING_05F11', text='', icon_value=string_to_icon('PREFERENCES'))
        if menu['sna_check_rotate']:
            op = row_84FB5.operator('wm.lock_view_rotation_disable_00640', text='', icon_value=string_to_icon('MESH_PLANE'), emboss=True, depress=False)
        else:
            op = row_84FB5.operator('wm.lock_view_rotation_enable_8929b', text='', icon_value=string_to_icon('ORIENTATION_GIMBAL'), emboss=True, depress=False)
        op = row_84FB5.operator('wm.camera_action_switch_950fd', text='', icon_value=string_to_icon('OBJECT_HIDDEN'), emboss=True, depress=False)


class SNA_OT_Lock_View_Rotation_Enable_8929B(bpy.types.Operator):
    bl_idname = "wm.lock_view_rotation_enable_8929b"
    bl_label = "Lock View Rotation (Enable)"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        rotate = None
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.region_3d.lock_rotation = True
                rotate = area.spaces.active.region_3d.lock_rotation
        menu['sna_check_rotate'] = rotate
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Lock_View_Rotation_Disable_00640(bpy.types.Operator):
    bl_idname = "wm.lock_view_rotation_disable_00640"
    bl_label = "Lock View Rotation (Disable)"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        rotate = None
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.region_3d.lock_rotation = False
                rotate = area.spaces.active.region_3d.lock_rotation
        menu['sna_check_rotate'] = rotate
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def load_pre_handler_AAF85(dummy):
    rotate = None
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            if area.spaces.active.region_3d.lock_rotation == True :
                rotate = area.spaces.active.region_3d.lock_rotation
            else:
                rotate = area.spaces.active.region_3d.lock_rotation
    menu['sna_check_rotate'] = rotate


class SNA_OT_Set_To_Mp4_4Fc1E(bpy.types.Operator):
    bl_idname = "wm.set_to_mp4_4fc1e"
    bl_label = "Set to MP4"
    bl_description = "Set output setting to MP4"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sc = bpy.context.scene
        sc.render.image_settings.file_format = "FFMPEG"
        sc.render.ffmpeg.format = "MPEG4"
        sc.render.ffmpeg.codec = "H264"
        sc.render.ffmpeg.audio_codec = "AAC"
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_To_Mov_4C792(bpy.types.Operator):
    bl_idname = "wm.set_to_mov_4c792"
    bl_label = "Set to MOV"
    bl_description = "Set output setting to MOV (RGBA)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sc = bpy.context.scene
        sc.render.image_settings.file_format = "FFMPEG"
        sc.render.ffmpeg.format = "QUICKTIME"
        sc.render.ffmpeg.codec = "QTRLE"
        if sc.render.film_transparent == True:
            sc.render.image_settings.color_mode = "RGBA"
        else :
            sc.render.image_settings.color_mode = "RGB"
        sc.render.ffmpeg.audio_codec = "AAC"
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_To_Png_9C466(bpy.types.Operator):
    bl_idname = "wm.set_to_png_9c466"
    bl_label = "Set to PNG"
    bl_description = "Set output setting to PNG"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sc = bpy.context.scene
        sc.render.image_settings.file_format = "PNG"
        if sc.render.film_transparent == True:
            sc.render.image_settings.color_mode = "RGBA"
        else :
            sc.render.image_settings.color_mode = "RGB"
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Render_Layer_Keyframes_Default_Ec843(bpy.types.Operator):
    bl_idname = "wm.render_layer_keyframes_default_ec843"
    bl_label = "Render Layer Keyframes (Default)"
    bl_description = "Only render current layer's keyframes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        str_filename = bpy.context.scene.sna_frame_number_filenames
        frames = []
        scene = bpy.context.scene
        obj = bpy.context.object
        frmt = scene.render.image_settings.file_format
        fp = scene.render.filepath  # Get existing output path
        #scene.render.image_settings.file_format = 'PNG'  # Set output format to .png
        scene.render.image_settings.file_format = frmt
        if scene.render.film_transparent == True:
            scene.render.image_settings.color_mode = 'RGBA'
        else:
            scene.render.image_settings.color_mode = 'RGB'
        if obj.type == 'GREASEPENCIL':
        #    print(obj.data.layers.active)
            for i in obj.data.layers.active.frames:
                path = bpy.context.blend_data.filepath
                frames.append(int(i.frame_number))
            filename_number = 0
            for frame_nr in frames:
                scene.frame_set(frame_nr)  # Set current frame to the desired frame
                if str_filename == 'Counting Numbers':
                    filename_number += 1
                    scene.render.filepath = fp + str(filename_number)
                elif str_filename == 'Layer name + Counting Numbers':
                    filename_number += 1
                    scene.render.filepath = fp + str(obj.data.name) + "_" + str(filename_number).zfill(4)
                elif str_filename == 'Frame Numbers':
                    scene.render.filepath = fp + str(frame_nr)
                elif str_filename == 'Layer name + Frame Numbers':
                    scene.render.filepath = fp + str(obj.data.name) + "_" + str(frame_nr).zfill(4)
        #        scene.render.filepath = fp + "_" + str(frame_nr).zfill(4)  # Set output path to avoid overwriting
                bpy.ops.render.render(write_still=True)  # Render still image
            # Restore the original filepath
            scene.render.filepath = fp
        else:
            self.report({'ERROR'}, 'Select a Grease Pencil Layer !')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_RENDER_AND_EXPORT_6F5DF(bpy.types.Panel):
    bl_label = 'Render and Export'
    bl_idname = 'SNA_PT_RENDER_AND_EXPORT_6F5DF'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_F0D49 = layout.column(heading='', align=True)
        col_F0D49.alert = False
        col_F0D49.enabled = True
        col_F0D49.active = True
        col_F0D49.use_property_split = False
        col_F0D49.use_property_decorate = False
        col_F0D49.scale_x = 1.0
        col_F0D49.scale_y = 1.0
        col_F0D49.alignment = 'Expand'.upper()
        col_F0D49.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_FEA5B = col_F0D49.box()
        box_FEA5B.alert = False
        box_FEA5B.enabled = True
        box_FEA5B.active = True
        box_FEA5B.use_property_split = False
        box_FEA5B.use_property_decorate = False
        box_FEA5B.alignment = 'Expand'.upper()
        box_FEA5B.scale_x = 1.0
        box_FEA5B.scale_y = 1.0
        if not True: box_FEA5B.operator_context = "EXEC_DEFAULT"
        col_26941 = box_FEA5B.column(heading='', align=True)
        col_26941.alert = False
        col_26941.enabled = True
        col_26941.active = True
        col_26941.use_property_split = False
        col_26941.use_property_decorate = False
        col_26941.scale_x = 1.0
        col_26941.scale_y = 1.0
        col_26941.alignment = 'Expand'.upper()
        col_26941.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_26941.prop(bpy.context.scene.render, 'film_transparent', text='Transparent', icon_value=string_to_icon('TEXTURE'), emboss=True, toggle=True)
        col_26941.prop(bpy.context.scene.grease_pencil_settings, 'antialias_threshold', text='Antialiasing', icon_value=0, emboss=True)
        col_26941.prop(bpy.context.scene.render, 'dither_intensity', text='Dithering', icon_value=0, emboss=True)
        box_71042 = col_F0D49.box()
        box_71042.alert = False
        box_71042.enabled = True
        box_71042.active = True
        box_71042.use_property_split = False
        box_71042.use_property_decorate = False
        box_71042.alignment = 'Expand'.upper()
        box_71042.scale_x = 1.0
        box_71042.scale_y = 1.0
        if not True: box_71042.operator_context = "EXEC_DEFAULT"
        col_774E9 = box_71042.column(heading='', align=True)
        col_774E9.alert = False
        col_774E9.enabled = True
        col_774E9.active = True
        col_774E9.use_property_split = False
        col_774E9.use_property_decorate = False
        col_774E9.scale_x = 1.0
        col_774E9.scale_y = 1.0
        col_774E9.alignment = 'Expand'.upper()
        col_774E9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_774E9.operator('wm.set_to_mp4_4fc1e', text='Set to MP4', icon_value=string_to_icon('OUTPUT'), emboss=True, depress=False)
        op = col_774E9.operator('wm.set_to_mov_4c792', text='Set to MOV', icon_value=string_to_icon('OUTPUT'), emboss=True, depress=False)
        op = col_774E9.operator('wm.set_to_png_9c466', text='Set to PNG', icon_value=string_to_icon('OUTPUT'), emboss=True, depress=False)
        op = col_774E9.operator('wm.set_to_tga_fd0a3', text='Set to TGA', icon_value=string_to_icon('OUTPUT'), emboss=True, depress=False)
        box_A9121 = col_F0D49.box()
        box_A9121.alert = False
        box_A9121.enabled = True
        box_A9121.active = True
        box_A9121.use_property_split = False
        box_A9121.use_property_decorate = False
        box_A9121.alignment = 'Expand'.upper()
        box_A9121.scale_x = 1.0
        box_A9121.scale_y = 1.0
        if not True: box_A9121.operator_context = "EXEC_DEFAULT"
        box_A9121.label(text='RENDER KEYFRAMES', icon_value=0)
        box_A9121.prop(bpy.context.scene, 'sna_frame_number_filenames', text='Name', icon_value=0, emboss=True)
        box_667C9 = box_A9121.box()
        box_667C9.alert = False
        box_667C9.enabled = True
        box_667C9.active = True
        box_667C9.use_property_split = False
        box_667C9.use_property_decorate = False
        box_667C9.alignment = 'Expand'.upper()
        box_667C9.scale_x = 1.0
        box_667C9.scale_y = 1.0
        if not True: box_667C9.operator_context = "EXEC_DEFAULT"
        box_667C9.label(text='Target Current Layer', icon_value=0)
        col_8ED43 = box_667C9.column(heading='', align=True)
        col_8ED43.alert = False
        col_8ED43.enabled = True
        col_8ED43.active = True
        col_8ED43.use_property_split = False
        col_8ED43.use_property_decorate = False
        col_8ED43.scale_x = 1.0
        col_8ED43.scale_y = 1.0
        col_8ED43.alignment = 'Expand'.upper()
        col_8ED43.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_8ED43.operator('wm.render_layer_keyframes_default_ec843', text='Render', icon_value=string_to_icon('RENDERLAYERS'), emboss=True, depress=False)
        op = col_8ED43.operator('wm.render_layer_keyframes_svg_3543e', text='Render (SVG)', icon_value=string_to_icon('RENDERLAYERS'), emboss=True, depress=False)
        col_8ED43.label(text='(Exported in output path)', icon_value=0)
        box_CFE72 = box_A9121.box()
        box_CFE72.alert = False
        box_CFE72.enabled = True
        box_CFE72.active = True
        box_CFE72.use_property_split = False
        box_CFE72.use_property_decorate = False
        box_CFE72.alignment = 'Expand'.upper()
        box_CFE72.scale_x = 1.0
        box_CFE72.scale_y = 1.0
        if not True: box_CFE72.operator_context = "EXEC_DEFAULT"
        box_CFE72.label(text='Target All Bottom Layers', icon_value=0)
        col_E0D27 = box_CFE72.column(heading='', align=True)
        col_E0D27.alert = False
        col_E0D27.enabled = True
        col_E0D27.active = True
        col_E0D27.use_property_split = False
        col_E0D27.use_property_decorate = False
        col_E0D27.scale_x = 1.0
        col_E0D27.scale_y = 1.0
        col_E0D27.alignment = 'Expand'.upper()
        col_E0D27.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_FFDD1 = col_E0D27.column(heading='', align=True)
        col_FFDD1.alert = True
        col_FFDD1.enabled = True
        col_FFDD1.active = True
        col_FFDD1.use_property_split = False
        col_FFDD1.use_property_decorate = False
        col_FFDD1.scale_x = 1.0
        col_FFDD1.scale_y = 1.0
        col_FFDD1.alignment = 'Expand'.upper()
        col_FFDD1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_FFDD1.label(text='Type which Grease Pencil (Data)', icon_value=0)
        col_FFDD1.label(text='to export (separated by comma)', icon_value=0)
        col_FFDD1.prop(bpy.context.scene, 'sna_type_which_gp_to_renderexport', text='', icon_value=string_to_icon('OUTLINER_DATA_GREASEPENCIL'), emboss=True)
        op = col_E0D27.operator('wm.render_all_keyframes__b07bc', text='Render All', icon_value=string_to_icon('RENDERLAYERS'), emboss=True, depress=False)
        op = col_E0D27.operator('wm.export_xdts_457ec', text='Export XDTS', icon_value=string_to_icon('SPREADSHEET'), emboss=True, depress=False)
        col_E0D27.label(text="(Exported in project file's folder)", icon_value=0)


class SNA_OT_Export_Xdts_457Ec(bpy.types.Operator):
    bl_idname = "wm.export_xdts_457ec"
    bl_label = "Export XDTS"
    bl_description = "Export Grease Pencils Data's first layer keyframes to XDTS"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        GPData = bpy.context.scene.sna_type_which_gp_to_renderexport
        import json
        header = "" 
        layers = GPData.split(',');
        layers_id = []
        dict = {}
        duration = bpy.context.scene.frame_end # total duration (frames)
        fieldIds = [0,3,5]
        _tracks = {}
        _trackNo = layers_id
        timetables_data = []
        #-------------------------
        #for x in bpy.data.objects:
        #    if x.type == "GREASEPENCIL":
        #        layers.append(x.name)
        for i in enumerate(layers):
            layers_id.append(i[0])
        #-------------------------
        dict["header"] = {"cut":0,"scene":0}
        dict["timeTables"] = []
        _df = {"duration":duration}
        dict["timeTables"].append(_df)
        _fields = []
        _df["fields"] = _fields
        _ft = {"fieldId":fieldIds[0]}
        _fields.append(_ft)
        _tracks = []
        _ft["tracks"]= _tracks
        _tf={}
        frames_list= []
        #bpy.data.grease_pencils_v3['GPencil.001'].layers['a'].frames
        gg = -1
        for l in layers:
            gg += 1
            for g in bpy.data.grease_pencils_v3:
                if g.name == str(l):
                    _tf = {"trackNo":int(gg)}
                    _tf["frames"] = []
                    _tracks.append(_tf)
                    tt = 0
                    k = {str(g.name) : []}
                    frames_list.append(k)
                    for e in g.layers[0].frames:
                        if e.keyframe_type == "KEYFRAME":
                            tt += 1
                            _frames = { "data": [{ "id": 0,"values": [str(tt)] }]}
                        elif e.keyframe_type == "BREAKDOWN":
                            _frames = { "data": [{ "id": 0,"values": ["SYMBOL_TICK_1"] }]}
                        elif e.keyframe_type == "JITTER":
                            _frames = { "data": [{ "id": 0,"values": ["SYMBOL_TICK_2"] }]}
                        elif e.keyframe_type == "MOVING_HOLD":
                            _frames = { "data": [{ "id": 0,"values": ["SYMBOL_HYPHEN"] }]}
                        elif e.keyframe_type == "EXTREME":
                            _frames = { "data": [{ "id": 0,"values": ["SYMBOL_NULL_CELL"] }]}
                        kk = e.frame_number
                        _frames["frame"] = int(kk) - 1
                        _tf["frames"].append(_frames)
                    _frames = { "data": [{ "id": 0,"values": ["SYMBOL_NULL_CELL"] }]}    
                    _frames["frame"] = bpy.context.scene.frame_end
                    _tf["frames"].append(_frames)
        _df["name"] = header
        _df["timeTableHeaders"] = []
        _fn = {"fieldId":0}
        _fn["names"] = layers
        _df["timeTableHeaders"].append(_fn)
        dict["version"] = 5
        js = json.dumps(dict)
        filename = "Timesheet"
        filepath = "//"
        abs_filepath = bpy.path.abspath(filepath) # returns the absolute path
        if not os.path.isdir(str(abs_filepath+"export")): # checks whether the directory exists
            os.mkdir(str(abs_filepath+"export")) # if it does not yet exist, makes it
        fp = open(bpy.path.abspath("//"+"export/"+str(filename)+".xdts"), 'w')
        fp.write("exchangeDigitalTimeSheet Save Data"+js)
        fp.close()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Render_Layer_Keyframes_Svg_3543E(bpy.types.Operator):
    bl_idname = "wm.render_layer_keyframes_svg_3543e"
    bl_label = "Render Layer Keyframes (SVG)"
    bl_description = "Only render current layer's keyframes in SVG format"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        str_filename = bpy.context.scene.sna_frame_number_filenames
        frames = []
        scene = bpy.context.scene
        obj = bpy.context.object
        fp = scene.render.filepath  # Get existing output path
        if obj.type == 'GREASEPENCIL':
        #    print(obj.data.layers.active)
            for i in obj.data.layers.active.frames:
                path = bpy.context.blend_data.filepath
                frames.append(int(i.frame_number))
            filename_number = 0
            for frame_nr in frames:
                scene.frame_set(frame_nr)  # Set current frame to the desired frame
                srf = ''
                if str_filename == 'Counting Numbers':
                    filename_number += 1
                    srf = fp + str(filename_number) + ".svg"
                elif str_filename == 'Layer name + Counting Numbers':
                    filename_number += 1
                    srf = fp + str(obj.data.name) + "_" + str(filename_number).zfill(4) + ".svg"
                elif str_filename == 'Frame Numbers':
                    srf = fp + str(frame_nr)
                elif str_filename == 'Layer name + Frame Numbers':
                    srf = fp + str(obj.data.name) + "_" + str(frame_nr).zfill(4) + ".svg"
                bpy.ops.wm.grease_pencil_export_svg(
                    filepath=srf, 
                    check_existing=True, 
                    filter_blender=False, 
                    filter_backup=False, 
                    filter_image=False, 
                    filter_movie=False, 
                    filter_python=False, 
                    filter_font=False, 
                    filter_sound=False, 
                    filter_text=False, 
                    filter_archive=False, 
                    filter_btx=False, 
                    filter_collada=False, 
                    filter_alembic=False, 
                    filter_usd=False, 
                    filter_obj=True, 
                    filter_volume=False, 
                    filter_folder=True, 
                    filter_blenlib=False, 
        #            filemode=8, 
                    display_type='DEFAULT', 
        #            sort_method='', 
                    use_fill=True, 
                    selected_object_type='VISIBLE', 
                    stroke_sample=0.0, 
                    use_uniform_width=False, 
                    use_clip_camera=False
                    )
            # Restore the original filepath
            scene.render.filepath = fp
        else:
            self.report({'ERROR'}, 'Select a Grease Pencil Layer !')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_To_Tga_Fd0A3(bpy.types.Operator):
    bl_idname = "wm.set_to_tga_fd0a3"
    bl_label = "Set to TGA"
    bl_description = "Set output setting to TGA"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sc = bpy.context.scene
        sc.render.image_settings.file_format = "TARGA"
        if sc.render.film_transparent == True:
            sc.render.image_settings.color_mode = "RGBA"
        else :
            sc.render.image_settings.color_mode = "RGB"
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Render_All_Keyframes__B07Bc(bpy.types.Operator):
    bl_idname = "wm.render_all_keyframes__b07bc"
    bl_label = "Render All Keyframes "
    bl_description = "Render All Keyframes from all GPData you typed"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        GPData = bpy.context.scene.sna_type_which_gp_to_renderexport
        str_filename = bpy.context.scene.sna_frame_number_filenames
        filepath = "//"
        abs_filepath = bpy.path.abspath(filepath) # returns the absolute path
        if not os.path.isdir(str(abs_filepath+"export")): # checks whether the directory exists
            os.mkdir(str(abs_filepath+"export")) # if it does not yet exist, makes it
        layers = GPData.split(',');
        for l in layers:
            for a in bpy.data.objects:
                for b in layers:    
                    bpy.data.objects[str(b)].hide_render = True
                bpy.data.objects[str(l)].hide_render = False
                print(bpy.data.objects[str(a.name)].name,' = ',bpy.data.objects[str(a.name)].hide_render)
                scene = bpy.context.scene
                if str_filename == 'Counting Numbers' or str_filename == 'Frame Numbers' :
                    filename = ''
                elif str_filename == 'Layer name + Counting Numbers' or str_filename == 'Layer name + Frame Numbers' : 
                    filename = str(l)
                fp = abs_filepath+"export"+"/"+str(l)+"/"+filename  # Get existing output path
                frmt = scene.render.image_settings.file_format
                scene.render.image_settings.file_format = frmt #PNG
                if scene.render.film_transparent == True:
                    scene.render.image_settings.color_mode = 'RGBA'
                else:
                    scene.render.image_settings.color_mode = 'RGB'
            for b in bpy.data.objects:  
                frames = [] 
                obj = bpy.data.objects[str(b.name)]
                if obj.type == 'GREASEPENCIL':
                #    print(obj.data.layers.active)
                    for i in obj.data.layers.active.frames:
                        path = bpy.context.blend_data.filepath
                        frames.append(int(i.frame_number))
                    if obj.hide_render == False:
                        print(frames)
                        filename_number = 0
                        for frame_nr in frames:
                            if not os.path.isdir(str(abs_filepath+"export"+"/"+str(l))): # checks whether the directory exists
                                os.mkdir(str(abs_filepath+"export"+"/"+str(l))) # if it does not yet exist, makes it
                            scene.frame_set(frame_nr)  # Set current frame to the desired frame
                            if str_filename == 'Counting Numbers':
                                filename_number += 1
                                scene.render.filepath = abs_filepath+"export"+"/"+str(l)+"/"+str(filename_number)
                            elif str_filename == 'Layer name + Counting Numbers':
                                filename_number += 1
                                scene.render.filepath = fp + "_" + str(filename_number).zfill(4)
                            elif str_filename == 'Frame Numbers':
                                scene.render.filepath = abs_filepath+"export"+"/"+str(l)+"/"+str(frame_nr)
                            elif str_filename == 'Layer name + Frame Numbers':
                                scene.render.filepath = fp + "_" + str(frame_nr).zfill(4)
                            bpy.ops.render.render(write_still=True)  # Render still image
                        # Restore the original filepath
                        scene.render.filepath = fp
                    else:
                        pass
            print('----')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rotate_Clockwise_B155B(bpy.types.Operator):
    bl_idname = "wm.rotate_clockwise_b155b"
    bl_label = "Rotate Clockwise"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_rotation_shortcut:
            bpy.context.scene.sna_rotation_slider = float(bpy.context.scene.sna_rotation_slider - bpy.context.scene.sna_rotation_steps)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rotate_Counter_Clockwise_Acaed(bpy.types.Operator):
    bl_idname = "wm.rotate_counter_clockwise_acaed"
    bl_label = "Rotate Counter Clockwise"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_rotation_shortcut:
            bpy.context.scene.sna_rotation_slider = float(bpy.context.scene.sna_rotation_slider + bpy.context.scene.sna_rotation_steps)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_filter_gp_2AA1B(Input):
    Input = Input
    Mesh = bpy.context.scene.sna_include_mesh_objects
    Output = None
    if Input == None: pass
    else:
        string = str(Input.name)  
        index = string.find('#')  
        if index != -1: pass
        else :
            if Mesh == True :
                if Input.type == 'GREASEPENCIL' or Input.type == 'MESH' :
                    Output = True
                else:
                    Output = False
            else :
                if Input.type == 'GREASEPENCIL':
                    Output = True
                else:
                    Output = False
    return Output


class SNA_OT_Enable_Grease_Pencil_Opacity_D52Eb(bpy.types.Operator):
    bl_idname = "wm.enable_grease_pencil_opacity_d52eb"
    bl_label = "Enable Grease Pencil Opacity"
    bl_description = "Add Opacity Modifier to Active Grease Pencil Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        default_opacity = bpy.context.scene.sna_opacity_default
        obj = bpy.context.active_object
        # Explicitly check if the modifier 'sakugagp_opacity' exists in the active object's modifiers
        modifier_exists = "sakugagp_opacity" in [mod.name for mod in obj.modifiers]
        if not modifier_exists:
        #    # Only create a new modifier if it does not exist
            if obj and obj.type =='GREASEPENCIL':
                op=obj.modifiers.new(name='sakugagp_opacity',type='GREASE_PENCIL_OPACITY')
                op.color_factor = default_opacity
        else : pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def depsgraph_update_pre_handler_02B43(dummy):
    node_found = None
    if bpy.context.active_object == None : pass
    else:
        if bpy.context.active_object.type == 'MESH':
            if bpy.context.active_object.active_material == None:
                pass
            else:
                mat_name = bpy.context.active_object.active_material.name
                mat = bpy.data.materials[mat_name]
                if mat.use_nodes:
                    ntree = mat.node_tree
                    node = ntree.nodes.get("sakugagp_opacity", None)
                    if node is not None:
                        node_found = True
                    else:
                        node_found = False
                else: pass
        else: pass
    #print(bpy.data.objects['Plane'].active_material.name)
    selector['sna_opacity_mesh_check'] = node_found


class SNA_OT_Enable_Image_Mesh_Plane_Opacity_De052(bpy.types.Operator):
    bl_idname = "wm.enable_image_mesh_plane_opacity_de052"
    bl_label = "Enable Image Mesh Plane Opacity"
    bl_description = "Add alpha slider to Image Mesh Plane Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj_name = bpy.context.object.name
        mat_name = bpy.context.active_object.active_material.name
        mat = (bpy.data.materials.get(mat_name))
        if mat.use_nodes:
            if obj_name == mat_name :
                mat.blend_method = "BLEND"
                nodes = mat.node_tree.nodes
                links = mat.node_tree.links
                image_texture_node = nodes.get("Image Texture")
                math_node = mat.node_tree.nodes.new('ShaderNodeMath')
                math_node.operation = 'MULTIPLY'
                math_node.name = "sakugagp_opacity"
                math_node.label = "sakugagp_opacity"
                ntree = mat.node_tree
                node_bsdf = ntree.nodes.get("Principled BSDF", None)
                node_mix = ntree.nodes.get("Mix Shader", None)
                if node_bsdf is not None:
                    bsdf_shader_node = nodes.get("Principled BSDF")
                    links.new(image_texture_node.outputs['Alpha'], math_node.inputs[0])
                    links.new(math_node.outputs[0], bsdf_shader_node.inputs['Alpha'])
                elif node_mix is not None:
                    mix_shader_node = nodes.get("Mix Shader")
                    links.new(image_texture_node.outputs['Alpha'], math_node.inputs[0])
                    links.new(math_node.outputs[0], mix_shader_node.inputs['Fac'])
        else: pass
        bpy.context.scene.sna_opacity_mesh = bpy.context.scene.sna_opacity_default
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Disable_Image_Mesh_Plane_Opacity_E26A2(bpy.types.Operator):
    bl_idname = "wm.disable_image_mesh_plane_opacity_e26a2"
    bl_label = "Disable Image Mesh Plane Opacity"
    bl_description = "Remove alpha slider from Image Mesh Plane Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        node_found = False
        obj_name = bpy.context.object.name
        mat_name = bpy.context.active_object.active_material.name
        mat = bpy.data.materials[mat_name]
        if mat.use_nodes:
            if obj_name == mat_name :
                ntree = mat.node_tree
                node = ntree.nodes.get("sakugagp_opacity", None)
                if node is not None:
                    node_found = True
                    mat.node_tree.nodes.remove(node)
                    nodes = mat.node_tree.nodes
                    links = mat.node_tree.links
                    image_texture_node = nodes.get("Image Texture")
                    if mat.use_nodes:
                        ntree = mat.node_tree
                        node_bsdf = ntree.nodes.get("Principled BSDF", None)
                        node_mix = ntree.nodes.get("Mix Shader", None)
                        if node_bsdf is not None:
                            for link in node_bsdf.inputs[4].links:
                                mat.node_tree.links.remove(link)
        #                    bsdf_shader_node = nodes.get("Principled BSDF")
        #                    links.new(image_texture_node.outputs['Alpha'], bsdf_shader_node.inputs['Alpha'])
                        elif node_mix is not None:
                            node_mix.inputs[0].default_value = 1
                            for link in node_mix.inputs[0].links:
                                mat.node_tree.links.remove(link)
        #                    mix_shader_node = nodes.get("Mix Shader")
        #                    links.new(image_texture_node.outputs['Alpha'], mix_shader_node.inputs['Fac']) 
                else:
                    pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def depsgraph_update_pre_handler_697C5(dummy):
    modifier_found = None
    if bpy.context.active_object == None : pass
    else:
        if bpy.context.active_object.type == 'GREASEPENCIL':
            active_obj = bpy.context.active_object
            # Explicitly check if the modifier 'sakugagp_opacity' exists in the active object's modifiers
            modifier_exists = "sakugagp_opacity" in [mod.name for mod in active_obj.modifiers]
            if not modifier_exists:
                modifier_found = False
            else : 
                modifier_found = True
        else: pass
    selector['sna_opacity_gp_check'] = modifier_found


class SNA_OT_Disable_Gp_Opacity_7E22B(bpy.types.Operator):
    bl_idname = "wm.disable_gp_opacity_7e22b"
    bl_label = "Disable GP Opacity"
    bl_description = "Remove Opacity Modifier from Active Grease Pencil Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        default_opacity = None
        active_obj = bpy.context.active_object
        # Explicitly check if the modifier 'sakugagp_opacity' exists in the active object's modifiers
        modifier_exists = "sakugagp_opacity" in [mod.name for mod in active_obj.modifiers]
        if not modifier_exists:
            # Only create a new modifier if it does not exist
            pass
        else : 
            active_obj.modifiers.remove(active_obj.modifiers['sakugagp_opacity'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Bring_Object_Forward_E16E7(bpy.types.Operator):
    bl_idname = "wm.bring_object_forward_e16e7"
    bl_label = "Bring Object Forward"
    bl_description = "Y - 0.002"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.active_object is None :
            self.report({'ERROR'}, "Select a object! if object is hidden, unhide it")
        else :
            bpy.context.active_object.location.y -= 0.002
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Bring_Object_Backward_Aad11(bpy.types.Operator):
    bl_idname = "wm.bring_object_backward_aad11"
    bl_label = "Bring Object Backward"
    bl_description = "Y + 0.002"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.active_object is None :
            self.report({'ERROR'}, "Select a object! if object is hidden, unhide it")
        else :
            bpy.context.active_object.location.y += 0.002
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_From_List_05F1A(bpy.types.Operator):
    bl_idname = "wm.hide_from_list_05f1a"
    bl_label = "Hide from list"
    bl_description = "Hide selected object from list by inserting ' # ' to its name. Remove the ' # '  by renaming it from outliner to bring it back to the list"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        Input = None
        Input = bpy.context.active_object
        Input.name = "#" + str(Input.name)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_SELECTOR_MENU_D365D(bpy.types.Panel):
    bl_label = 'Selector Menu'
    bl_idname = 'SNA_PT_SELECTOR_MENU_D365D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_BBFDA = layout.box()
        box_BBFDA.alert = False
        box_BBFDA.enabled = True
        box_BBFDA.active = True
        box_BBFDA.use_property_split = False
        box_BBFDA.use_property_decorate = False
        box_BBFDA.alignment = 'Expand'.upper()
        box_BBFDA.scale_x = 1.0
        box_BBFDA.scale_y = 1.0
        if not True: box_BBFDA.operator_context = "EXEC_DEFAULT"
        col_FFE24 = box_BBFDA.column(heading='', align=True)
        col_FFE24.alert = False
        col_FFE24.enabled = True
        col_FFE24.active = True
        col_FFE24.use_property_split = False
        col_FFE24.use_property_decorate = False
        col_FFE24.scale_x = 1.0
        col_FFE24.scale_y = 1.0
        col_FFE24.alignment = 'Expand'.upper()
        col_FFE24.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_FFE24.label(text='Filter :', icon_value=0)
        col_FFE24.prop(bpy.context.scene, 'sna_include_mesh_objects', text='Include Mesh Objects', icon_value=string_to_icon('OUTLINER_OB_MESH'), emboss=True)
        op = col_FFE24.operator('wm.hide_from_list_05f1a', text='Exclude Object from the list', icon_value=string_to_icon('GRID'), emboss=True, depress=False)


@persistent
def depsgraph_update_pre_handler_D3288(dummy):
    Variable = None
    has_image = None
    obj = bpy.context.active_object
    if obj.type == "EMPTY":
        if obj.empty_display_type == "IMAGE":
            has_image = True
        else:
            has_image = False
    else: pass
    selector['sna_opacity_ref_check'] = has_image


class SNA_OT_Enable_Ref_Opacity_5375E(bpy.types.Operator):
    bl_idname = "wm.enable_ref_opacity_5375e"
    bl_label = "Enable Ref Opacity"
    bl_description = "Enable opacity to Image Reference"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj = bpy.context.active_object
        obj.use_empty_image_alpha = True
        bpy.context.scene.sna_opacity_ref = bpy.context.scene.sna_opacity_default
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Disable_Ref_Opacity_Ddd03(bpy.types.Operator):
    bl_idname = "wm.disable_ref_opacity_ddd03"
    bl_label = "Disable Ref Opacity"
    bl_description = "Disable opacity to Image Reference"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        default_opacity = None
        obj = bpy.context.object
        obj.use_empty_image_alpha = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_SELECTOR_85546(bpy.types.Panel):
    bl_label = 'Selector'
    bl_idname = 'SNA_PT_SELECTOR_85546'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'SakugaGP'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_E5D76 = layout.column(heading='', align=False)
        col_E5D76.alert = False
        col_E5D76.enabled = True
        col_E5D76.active = True
        col_E5D76.use_property_split = False
        col_E5D76.use_property_decorate = False
        col_E5D76.scale_x = 1.0
        col_E5D76.scale_y = 1.0
        col_E5D76.alignment = 'Expand'.upper()
        col_E5D76.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if (selector['sna_opacity_ref_check'] and bpy.context.view_layer.objects.active.use_empty_image_alpha):
            col_22F40 = col_E5D76.column(heading='', align=False)
            col_22F40.alert = False
            col_22F40.enabled = True
            col_22F40.active = True
            col_22F40.use_property_split = False
            col_22F40.use_property_decorate = False
            col_22F40.scale_x = 1.0
            col_22F40.scale_y = 1.0
            col_22F40.alignment = 'Expand'.upper()
            col_22F40.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_22F40.prop(bpy.context.scene, 'sna_opacity_ref', text='Opacity', icon_value=0, emboss=True)
            col_22F40.prop(bpy.context.view_layer.objects.active, 'color', text='', icon_value=0, emboss=True)
        else:
            if selector['sna_opacity_gp_check']:
                col_E5D76.prop(bpy.context.view_layer.objects.active.modifiers['sakugagp_opacity'], 'color_factor', text='Opacity', icon_value=0, emboss=True)
            else:
                if selector['sna_opacity_mesh_check']:
                    col_E5D76.prop(bpy.context.scene, 'sna_opacity_mesh', text='Opacity', icon_value=0, emboss=True)
        row_D48B0 = col_E5D76.row(heading='', align=True)
        row_D48B0.alert = False
        row_D48B0.enabled = True
        row_D48B0.active = True
        row_D48B0.use_property_split = False
        row_D48B0.use_property_decorate = False
        row_D48B0.scale_x = 1.0
        row_D48B0.scale_y = 1.0
        row_D48B0.alignment = 'Expand'.upper()
        row_D48B0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('FECBF', locals())
        row_D48B0.template_list('SNA_UL_display_collection_list_FECBF', coll_id, bpy.data, 'objects', bpy.context.scene, 'sna_object_list', rows=0)
        col_B97BA = row_D48B0.column(heading='', align=False)
        col_B97BA.alert = False
        col_B97BA.enabled = True
        col_B97BA.active = True
        col_B97BA.use_property_split = False
        col_B97BA.use_property_decorate = False
        col_B97BA.scale_x = 1.0
        col_B97BA.scale_y = 1.0
        col_B97BA.alignment = 'Expand'.upper()
        col_B97BA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_B97BA.popover('SNA_PT_SELECTOR_MENU_D365D', text='', icon_value=string_to_icon('COLLAPSEMENU'))
        if (bpy.context.view_layer.objects.active == None):
            pass
        else:
            col_B2F92 = col_B97BA.column(heading='', align=False)
            col_B2F92.alert = False
            col_B2F92.enabled = True
            col_B2F92.active = True
            col_B2F92.use_property_split = False
            col_B2F92.use_property_decorate = False
            col_B2F92.scale_x = 1.0
            col_B2F92.scale_y = 1.0
            col_B2F92.alignment = 'Expand'.upper()
            col_B2F92.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_46D9A = col_B2F92.column(heading='', align=True)
            col_46D9A.alert = False
            col_46D9A.enabled = True
            col_46D9A.active = True
            col_46D9A.use_property_split = False
            col_46D9A.use_property_decorate = False
            col_46D9A.scale_x = 1.0
            col_46D9A.scale_y = 1.0
            col_46D9A.alignment = 'Expand'.upper()
            col_46D9A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_46D9A.operator('wm.bring_object_forward_e16e7', text='', icon_value=string_to_icon('TRIA_UP'), emboss=True, depress=False)
            op = col_46D9A.operator('wm.bring_object_backward_aad11', text='', icon_value=string_to_icon('TRIA_DOWN'), emboss=True, depress=False)
            if (bpy.context.view_layer.objects.active == None):
                pass
            else:
                if bpy.context.view_layer.objects.active.type == 'CAMERA':
                    pass
                else:
                    if selector['sna_opacity_ref_check']:
                        if bpy.context.view_layer.objects.active.use_empty_image_alpha:
                            op = col_B2F92.operator('wm.disable_ref_opacity_ddd03', text='', icon_value=string_to_icon('MOD_OPACITY'), emboss=True, depress=True)
                        else:
                            op = col_B2F92.operator('wm.enable_ref_opacity_5375e', text='', icon_value=string_to_icon('MOD_OPACITY'), emboss=True, depress=False)
                    else:
                        if bpy.context.view_layer.objects.active.type == 'MESH':
                            if selector['sna_opacity_mesh_check']:
                                op = col_B2F92.operator('wm.disable_image_mesh_plane_opacity_e26a2', text='', icon_value=string_to_icon('MOD_OPACITY'), emboss=True, depress=True)
                            else:
                                op = col_B2F92.operator('wm.enable_image_mesh_plane_opacity_de052', text='', icon_value=string_to_icon('MOD_OPACITY'), emboss=True, depress=False)
                        else:
                            if selector['sna_opacity_gp_check']:
                                op = col_B2F92.operator('wm.disable_gp_opacity_7e22b', text='', icon_value=string_to_icon('MOD_OPACITY'), emboss=True, depress=True)
                            else:
                                op = col_B2F92.operator('wm.enable_grease_pencil_opacity_d52eb', text='', icon_value=string_to_icon('MOD_OPACITY'), emboss=True, depress=False)


class SNA_PT_SETTING_05F11(bpy.types.Panel):
    bl_label = 'Setting'
    bl_idname = 'SNA_PT_SETTING_05F11'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_DD56A = layout.column(heading='', align=False)
        col_DD56A.alert = False
        col_DD56A.enabled = True
        col_DD56A.active = True
        col_DD56A.use_property_split = False
        col_DD56A.use_property_decorate = False
        col_DD56A.scale_x = 1.0
        col_DD56A.scale_y = 1.0
        col_DD56A.alignment = 'Expand'.upper()
        col_DD56A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_80B6C = col_DD56A.column(heading='', align=True)
        col_80B6C.alert = False
        col_80B6C.enabled = True
        col_80B6C.active = True
        col_80B6C.use_property_split = False
        col_80B6C.use_property_decorate = False
        col_80B6C.scale_x = 1.0
        col_80B6C.scale_y = 1.0
        col_80B6C.alignment = 'Expand'.upper()
        col_80B6C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_80B6C.label(text='Camera', icon_value=0)
        col_1F89F = col_80B6C.column(heading='', align=True)
        col_1F89F.alert = False
        col_1F89F.enabled = True
        col_1F89F.active = True
        col_1F89F.use_property_split = False
        col_1F89F.use_property_decorate = False
        col_1F89F.scale_x = 1.0
        col_1F89F.scale_y = 1.0
        col_1F89F.alignment = 'Expand'.upper()
        col_1F89F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_DCE47 = col_1F89F.box()
        box_DCE47.alert = False
        box_DCE47.enabled = True
        box_DCE47.active = True
        box_DCE47.use_property_split = False
        box_DCE47.use_property_decorate = False
        box_DCE47.alignment = 'Expand'.upper()
        box_DCE47.scale_x = 1.0
        box_DCE47.scale_y = 1.0
        if not True: box_DCE47.operator_context = "EXEC_DEFAULT"
        col_71E56 = box_DCE47.column(heading='', align=True)
        col_71E56.alert = False
        col_71E56.enabled = True
        col_71E56.active = True
        col_71E56.use_property_split = False
        col_71E56.use_property_decorate = False
        col_71E56.scale_x = 1.0
        col_71E56.scale_y = 1.0
        col_71E56.alignment = 'Expand'.upper()
        col_71E56.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_71E56.prop(bpy.context.scene, 'sna_camera_action_1_name', text='', icon_value=string_to_icon('EVENT_NDOF_BUTTON_1'), emboss=True)
        col_71E56.prop(bpy.context.scene, 'sna_camera_action_2_name', text='', icon_value=string_to_icon('EVENT_NDOF_BUTTON_2'), emboss=True)
        col_71E56.prop(bpy.context.scene, 'sna_toggle_overscan_as_well', text='Toggle Overscan as well', icon_value=0, emboss=True)
        op = col_71E56.operator('wm.camera_action_switch_950fd', text='Camera Action Switch', icon_value=string_to_icon('OBJECT_HIDDEN'), emboss=True, depress=False)
        col_1F89F.separator(factor=1.0)
        box_0A676 = col_1F89F.box()
        box_0A676.alert = False
        box_0A676.enabled = True
        box_0A676.active = True
        box_0A676.use_property_split = False
        box_0A676.use_property_decorate = False
        box_0A676.alignment = 'Expand'.upper()
        box_0A676.scale_x = 1.0
        box_0A676.scale_y = 1.0
        if not True: box_0A676.operator_context = "EXEC_DEFAULT"
        col_6BE0B = box_0A676.column(heading='', align=True)
        col_6BE0B.alert = False
        col_6BE0B.enabled = True
        col_6BE0B.active = True
        col_6BE0B.use_property_split = False
        col_6BE0B.use_property_decorate = False
        col_6BE0B.scale_x = 1.0
        col_6BE0B.scale_y = 1.0
        col_6BE0B.alignment = 'Expand'.upper()
        col_6BE0B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_6BE0B.prop(bpy.context.scene, 'sna_rotation_shortcut', text='Rotation Shortcuts', icon_value=0, emboss=True)
        col_6BE0B.label(text='Rotate Right : ALT+PERIOD', icon_value=0)
        col_6BE0B.label(text='Rotate Left : ALT+COMMA', icon_value=0)
        col_6BE0B.prop(bpy.context.scene, 'sna_rotation_steps', text='Rotation Steps', icon_value=0, emboss=True)
        col_91E73 = col_DD56A.column(heading='', align=True)
        col_91E73.alert = False
        col_91E73.enabled = True
        col_91E73.active = True
        col_91E73.use_property_split = False
        col_91E73.use_property_decorate = False
        col_91E73.scale_x = 1.0
        col_91E73.scale_y = 1.0
        col_91E73.alignment = 'Expand'.upper()
        col_91E73.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_91E73.label(text='Selector', icon_value=0)
        box_20EC6 = col_91E73.box()
        box_20EC6.alert = False
        box_20EC6.enabled = True
        box_20EC6.active = True
        box_20EC6.use_property_split = False
        box_20EC6.use_property_decorate = False
        box_20EC6.alignment = 'Expand'.upper()
        box_20EC6.scale_x = 1.0
        box_20EC6.scale_y = 1.0
        if not True: box_20EC6.operator_context = "EXEC_DEFAULT"
        col_3B31E = box_20EC6.column(heading='', align=True)
        col_3B31E.alert = False
        col_3B31E.enabled = True
        col_3B31E.active = True
        col_3B31E.use_property_split = False
        col_3B31E.use_property_decorate = False
        col_3B31E.scale_x = 1.0
        col_3B31E.scale_y = 1.0
        col_3B31E.alignment = 'Expand'.upper()
        col_3B31E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_3B31E.prop(bpy.context.scene, 'sna_opacity_default', text='Default Opacity', icon_value=0, emboss=True)
        col_E9CEB = col_DD56A.column(heading='', align=True)
        col_E9CEB.alert = False
        col_E9CEB.enabled = True
        col_E9CEB.active = True
        col_E9CEB.use_property_split = False
        col_E9CEB.use_property_decorate = False
        col_E9CEB.scale_x = 1.0
        col_E9CEB.scale_y = 1.0
        col_E9CEB.alignment = 'Expand'.upper()
        col_E9CEB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_E9CEB.label(text='Set Playback Range and FPS', icon_value=0)
        box_E2FB0 = col_E9CEB.box()
        box_E2FB0.alert = False
        box_E2FB0.enabled = True
        box_E2FB0.active = True
        box_E2FB0.use_property_split = False
        box_E2FB0.use_property_decorate = False
        box_E2FB0.alignment = 'Expand'.upper()
        box_E2FB0.scale_x = 1.0
        box_E2FB0.scale_y = 1.0
        if not True: box_E2FB0.operator_context = "EXEC_DEFAULT"
        col_0B91A = box_E2FB0.column(heading='', align=True)
        col_0B91A.alert = False
        col_0B91A.enabled = True
        col_0B91A.active = True
        col_0B91A.use_property_split = False
        col_0B91A.use_property_decorate = False
        col_0B91A.scale_x = 1.0
        col_0B91A.scale_y = 1.0
        col_0B91A.alignment = 'Expand'.upper()
        col_0B91A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_0B91A.prop(bpy.context.scene, 'sna_hide_set_startendfps_in_timeline', text='Hide on Timeline', icon_value=0, emboss=True)
        col_0B91A.prop(bpy.context.scene, 'sna_hide_set_startendfps_in_dopesheet', text='Hide on Dopesheet', icon_value=0, emboss=True)
        col_6A3F3 = col_DD56A.column(heading='', align=True)
        col_6A3F3.alert = False
        col_6A3F3.enabled = True
        col_6A3F3.active = True
        col_6A3F3.use_property_split = False
        col_6A3F3.use_property_decorate = False
        col_6A3F3.scale_x = 1.0
        col_6A3F3.scale_y = 1.0
        col_6A3F3.alignment = 'Expand'.upper()
        col_6A3F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_6A3F3.label(text='Toolbar', icon_value=0)
        box_AFA2E = col_6A3F3.box()
        box_AFA2E.alert = False
        box_AFA2E.enabled = True
        box_AFA2E.active = True
        box_AFA2E.use_property_split = False
        box_AFA2E.use_property_decorate = False
        box_AFA2E.alignment = 'Expand'.upper()
        box_AFA2E.scale_x = 1.0
        box_AFA2E.scale_y = 1.0
        if not True: box_AFA2E.operator_context = "EXEC_DEFAULT"
        col_5CF0F = box_AFA2E.column(heading='', align=True)
        col_5CF0F.alert = False
        col_5CF0F.enabled = True
        col_5CF0F.active = True
        col_5CF0F.use_property_split = False
        col_5CF0F.use_property_decorate = False
        col_5CF0F.scale_x = 1.0
        col_5CF0F.scale_y = 1.0
        col_5CF0F.alignment = 'Expand'.upper()
        col_5CF0F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_5CF0F.prop(bpy.context.scene, 'sna_hide_all', text='Hide All', icon_value=0, emboss=True)
        col_5CF0F.prop(bpy.context.scene, 'sna_hide_camera', text='Hide Camera', icon_value=0, emboss=True)
        col_5CF0F.prop(bpy.context.scene, 'sna_hide_copas', text='Hide Copas', icon_value=0, emboss=True)
        col_5CF0F.prop(bpy.context.scene, 'sna_hide_tools', text='Hide Tools', icon_value=0, emboss=True)
        col_5CF0F.prop(bpy.context.scene, 'sna_hide_strokes', text='Hide Strokes', icon_value=0, emboss=True)
        box_85A83 = col_5CF0F.box()
        box_85A83.alert = False
        box_85A83.enabled = True
        box_85A83.active = True
        box_85A83.use_property_split = False
        box_85A83.use_property_decorate = False
        box_85A83.alignment = 'Expand'.upper()
        box_85A83.scale_x = 1.0
        box_85A83.scale_y = 1.0
        if not True: box_85A83.operator_context = "EXEC_DEFAULT"
        col_73A8A = box_85A83.column(heading='', align=True)
        col_73A8A.alert = False
        col_73A8A.enabled = True
        col_73A8A.active = True
        col_73A8A.use_property_split = False
        col_73A8A.use_property_decorate = False
        col_73A8A.scale_x = 1.0
        col_73A8A.scale_y = 1.0
        col_73A8A.alignment = 'Expand'.upper()
        col_73A8A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_73A8A.label(text='Brush Unit Size Converter', icon_value=0)
        col_73A8A.prop(bpy.context.scene, 'sna_show_brush_size_converter_pixel_to_meter', text='Pixel to Meter', icon_value=0, emboss=True)


class SNA_OT_Camera_Action_Switch_950Fd(bpy.types.Operator):
    bl_idname = "wm.camera_action_switch_950fd"
    bl_label = "Camera Action Switch"
    bl_description = "Switch between Camera's Actions you set in the setting"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        CO = bpy.context.scene.sna_camera_action_2_name
        CA = bpy.context.scene.sna_camera_action_1_name
        OV = bpy.context.scene.sna_toggle_overscan_as_well
        object = bpy.context.scene.camera
        action = object.animation_data.action
        CameraOverscan = CO
        CameraAction = CA
        if OV == True:
            if bpy.context.scene.camera_overscan.activate == False:
                bpy.context.scene.camera_overscan.activate = True
                bpy.context.scene.camera.animation_data.action = bpy.data.actions.get(str(CameraOverscan))
            else:
                bpy.context.scene.camera_overscan.activate = False
                bpy.context.scene.camera.animation_data.action = bpy.data.actions.get(str(CameraAction))
        else:
            if bpy.context.scene.camera.animation_data.action == bpy.data.actions.get(str(CameraOverscan)):
                bpy.context.scene.camera.animation_data.action = bpy.data.actions.get(str(CameraAction))
            elif bpy.context.scene.camera.animation_data.action == bpy.data.actions.get(str(CameraAction)):
                bpy.context.scene.camera.animation_data.action = bpy.data.actions.get(str(CameraOverscan))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_time_mt_editor_menus_DB484(self, context):
    if not (bpy.context.scene.sna_hide_set_startendfps_in_timeline):
        layout = self.layout
        row_AF463 = layout.row(heading='', align=True)
        row_AF463.alert = False
        row_AF463.enabled = True
        row_AF463.active = True
        row_AF463.use_property_split = False
        row_AF463.use_property_decorate = False
        row_AF463.scale_x = 1.0
        row_AF463.scale_y = 1.0
        row_AF463.alignment = 'Expand'.upper()
        row_AF463.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_AF463.operator('wm.set_start_c1539', text='', icon_value=string_to_icon('EVENT_LEFTBRACKET'), emboss=True, depress=False)
        op = row_AF463.operator('wm.set_end_0b987', text='', icon_value=string_to_icon('EVENT_RIGHTBRACKET'), emboss=True, depress=False)
        row_FC3CF = row_AF463.row(heading='', align=True)
        row_FC3CF.alert = False
        row_FC3CF.enabled = True
        row_FC3CF.active = True
        row_FC3CF.use_property_split = False
        row_FC3CF.use_property_decorate = False
        row_FC3CF.scale_x = 0.800000011920929
        row_FC3CF.scale_y = 1.0
        row_FC3CF.alignment = 'Expand'.upper()
        row_FC3CF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FC3CF.prop(bpy.context.scene.render, 'fps', text='', icon_value=805, emboss=True)


class SNA_OT_Set_Start_C1539(bpy.types.Operator):
    bl_idname = "wm.set_start_c1539"
    bl_label = "Set Start"
    bl_description = "Set start of the playback to current frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.frame_start = bpy.context.scene.frame_current
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_End_0B987(bpy.types.Operator):
    bl_idname = "wm.set_end_0b987"
    bl_label = "Set End"
    bl_description = "Set end of the playback to current frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.frame_end = bpy.context.scene.frame_current
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_dopesheet_mt_editor_menus_4BB55(self, context):
    if not (bpy.context.scene.sna_hide_set_startendfps_in_dopesheet):
        layout = self.layout
        row_568F3 = layout.row(heading='', align=True)
        row_568F3.alert = False
        row_568F3.enabled = True
        row_568F3.active = True
        row_568F3.use_property_split = False
        row_568F3.use_property_decorate = False
        row_568F3.scale_x = 1.0
        row_568F3.scale_y = 1.0
        row_568F3.alignment = 'Expand'.upper()
        row_568F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_568F3.operator('wm.set_start_c1539', text='', icon_value=string_to_icon('EVENT_LEFTBRACKET'), emboss=True, depress=False)
        op = row_568F3.operator('wm.set_end_0b987', text='', icon_value=string_to_icon('EVENT_RIGHTBRACKET'), emboss=True, depress=False)
        row_C176B = row_568F3.row(heading='', align=True)
        row_C176B.alert = False
        row_C176B.enabled = True
        row_C176B.active = True
        row_C176B.use_property_split = False
        row_C176B.use_property_decorate = False
        row_C176B.scale_x = 0.800000011920929
        row_C176B.scale_y = 1.0
        row_C176B.alignment = 'Expand'.upper()
        row_C176B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_C176B.prop(bpy.context.scene.render, 'fps', text='', icon_value=805, emboss=True)


class SNA_PT_OBJECT_EC829(bpy.types.Panel):
    bl_label = 'Object'
    bl_idname = 'SNA_PT_OBJECT_EC829'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_GREASE_PENCIL_D473A'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_B4840 = layout.column(heading='', align=True)
        col_B4840.alert = False
        col_B4840.enabled = True
        col_B4840.active = True
        col_B4840.use_property_split = False
        col_B4840.use_property_decorate = False
        col_B4840.scale_x = 1.0
        col_B4840.scale_y = 1.0
        col_B4840.alignment = 'Expand'.upper()
        col_B4840.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_B4840.operator('wm.add_empty_with_all_materials_abd31', text='Add GP with All Materials', icon_value=string_to_icon('OUTLINER_OB_GREASEPENCIL'), emboss=True, depress=False)
        op = col_B4840.operator('wm.add_empty_without_materials_7097f', text='Add GP without Materials', icon_value=string_to_icon('OUTLINER_OB_GREASEPENCIL'), emboss=True, depress=False)


class SNA_PT_MATERIAL_19385(bpy.types.Panel):
    bl_label = 'Material'
    bl_idname = 'SNA_PT_MATERIAL_19385'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_GREASE_PENCIL_D473A'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not tools['sna_is_greasepencil']))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_6E257 = layout.column(heading='', align=True)
        col_6E257.alert = False
        col_6E257.enabled = True
        col_6E257.active = True
        col_6E257.use_property_split = False
        col_6E257.use_property_decorate = False
        col_6E257.scale_x = 1.0
        col_6E257.scale_y = 1.0
        col_6E257.alignment = 'Expand'.upper()
        col_6E257.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_6E257.operator('wm.add_material_stroke_only_s_f198a', text='Add Material Stroke Only', icon_value=string_to_icon('PLUS'), emboss=True, depress=False)
        op = col_6E257.operator('wm.add_material_fill_only_f_b7e95', text='Add Material Fill Only', icon_value=string_to_icon('PLUS'), emboss=True, depress=False)
        op = col_6E257.operator('wm.add_material_stroke_and_fill_b_b_for_both_581b7', text='Add Material Stroke+Fill', icon_value=string_to_icon('PLUS'), emboss=True, depress=False)
        col_E1F06 = layout.column(heading='', align=True)
        col_E1F06.alert = False
        col_E1F06.enabled = True
        col_E1F06.active = True
        col_E1F06.use_property_split = False
        col_E1F06.use_property_decorate = False
        col_E1F06.scale_x = 1.0
        col_E1F06.scale_y = 1.0
        col_E1F06.alignment = 'Expand'.upper()
        col_E1F06.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E1F06.operator('wm.link_all_materials_a41fe', text='Link All Material', icon_value=string_to_icon('LINKED'), emboss=True, depress=False)
        op = col_E1F06.operator('wm.unlink_all_materials_7fc01', text='Unlink All Material', icon_value=string_to_icon('UNLINKED'), emboss=True, depress=False)
        col_C4F2E = layout.column(heading='', align=False)
        col_C4F2E.alert = False
        col_C4F2E.enabled = True
        col_C4F2E.active = True
        col_C4F2E.use_property_split = False
        col_C4F2E.use_property_decorate = False
        col_C4F2E.scale_x = 1.0
        col_C4F2E.scale_y = 1.0
        col_C4F2E.alignment = 'Expand'.upper()
        col_C4F2E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_C4F2E.operator('wm.delete_material_238fa', text='Delete Active Material', icon_value=string_to_icon('TRASH'), emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_rotation_slider = bpy.props.FloatProperty(name='Rotation Slider', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6, update=sna_update_sna_rotation_slider_BF78B)
    bpy.types.Scene.sna_rotation_steps = bpy.props.FloatProperty(name='Rotation Steps', description='', default=0.05000000074505806, subtype='NONE', unit='NONE', min=0.0, step=5, precision=2)
    bpy.types.Scene.sna_hide_tools = bpy.props.BoolProperty(name='Hide Tools', description='', default=False)
    bpy.types.Scene.sna_hide_camera = bpy.props.BoolProperty(name='Hide Camera', description='', default=False)
    bpy.types.Scene.sna_hide_copas = bpy.props.BoolProperty(name='Hide Copas', description='', default=False)
    bpy.types.Scene.sna_hide_strokes = bpy.props.BoolProperty(name='Hide Strokes', description='', default=False)
    bpy.types.Scene.sna_hide_object = bpy.props.BoolProperty(name='Hide Object', description='', default=False)
    bpy.types.Scene.sna_hide_all = bpy.props.BoolProperty(name='Hide All', description='', default=False, update=sna_update_sna_hide_all_B8EB4)
    bpy.types.Scene.sna_mute_camera_action = bpy.props.BoolProperty(name='Mute Camera Action', description='', default=False, update=sna_update_sna_mute_camera_action_27A28)
    bpy.types.Scene.sna_object_list = bpy.props.IntProperty(name='Object List', description='', default=0, subtype='NONE', update=sna_update_sna_object_list_EDFF0)
    bpy.types.Scene.sna_include_mesh_objects = bpy.props.BoolProperty(name='Include Mesh Objects', description='', default=False)
    bpy.types.Scene.sna_opacity_ref = bpy.props.FloatProperty(name='opacity_ref', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, max=1.0, step=3, precision=2, update=sna_update_sna_opacity_ref_6D10B)
    bpy.types.Scene.sna_opacity_mesh = bpy.props.FloatProperty(name='opacity_mesh', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, max=1.0, step=3, precision=2, update=sna_update_sna_opacity_mesh_E925E)
    bpy.types.Scene.sna_hide_set_startendfps_in_timeline = bpy.props.BoolProperty(name='Hide Set Start/End/Fps in Timeline', description='', default=False)
    bpy.types.Scene.sna_hide_set_startendfps_in_dopesheet = bpy.props.BoolProperty(name='Hide Set Start/End/Fps in Dopesheet', description='', default=True)
    bpy.types.Scene.sna_opacity_default = bpy.props.FloatProperty(name='opacity_default', description='', default=0.30000001192092896, subtype='NONE', unit='NONE', min=0.0, max=1.0, step=5, precision=2)
    bpy.types.Scene.sna_rotation_shortcut = bpy.props.BoolProperty(name='Rotation Shortcut', description='', default=True)
    bpy.types.Scene.sna_camera_action_switch = bpy.props.BoolProperty(name='Camera Action Switch', description='', default=False)
    bpy.types.Scene.sna_camera_action_1_name = bpy.props.StringProperty(name='Camera Action 1 Name', description='', default='CameraAction', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_camera_action_2_name = bpy.props.StringProperty(name='Camera Action 2 Name', description='', default='CameraOverscan', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_toggle_overscan_as_well = bpy.props.BoolProperty(name='Toggle Overscan as well', description='', default=True)
    bpy.types.Scene.sna_brush_size = bpy.props.IntProperty(name='Brush Size', description='', default=0, subtype='PIXEL', min=0, update=sna_update_sna_brush_size_E295A)
    bpy.types.Scene.sna_show_brush_size_converter_pixel_to_meter = bpy.props.BoolProperty(name='Show Brush Size Converter (pixel to Meter)', description='', default=False)
    bpy.types.Scene.sna_type_which_gp_to_renderexport = bpy.props.StringProperty(name='Type which GP to render/export', description='', default='A,B,C', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_frame_number_filenames = bpy.props.EnumProperty(name='Frame number filenames', description='', items=[('Counting Numbers', 'Counting Numbers', '', 0, 0), ('Layer name + Counting Numbers', 'Layer name + Counting Numbers', '', 0, 1), ('Frame Numbers', 'Frame Numbers', '', 0, 2), ('Layer name + Frame Numbers', 'Layer name + Frame Numbers', '', 0, 3)])
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_2E5D2)
    bpy.utils.register_class(SNA_OT_Flip_X_A8E72)
    bpy.utils.register_class(SNA_OT_Flip_Y_8D615)
    bpy.utils.register_class(SNA_OT_Transform_Strokes_A04Ca)
    bpy.utils.register_class(SNA_OT_Split_7A0De)
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_13B73)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_B3A42)
    bpy.utils.register_class(SNA_OT_Lasso_Cf183)
    bpy.utils.register_class(SNA_OT_Brush_57D3A)
    bpy.utils.register_class(SNA_OT_Erase_9D8E8)
    bpy.utils.register_class(SNA_OT_Fill_88837)
    bpy.utils.register_class(SNA_OT_Line_A9A17)
    bpy.utils.register_class(SNA_OT_Sculpt_Bbd1C)
    bpy.utils.register_class(SNA_OT_Gradient_6A423)
    bpy.utils.register_class(SNA_OT_Trim_9D5Fa)
    bpy.utils.register_class(SNA_OT_Draw_Camera_Guide_B1399)
    bpy.utils.register_class(SNA_OT_Transform_Object_Ab8D4)
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_EDA18)
    bpy.utils.register_class(SNA_OT_Cut_50749)
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_679FF)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_172E3)
    bpy.utils.register_class(SNA_OT_Select_Active_Camera_81Ec7)
    bpy.utils.register_class(SNA_OT_Mirror_Camera_Horizontally_861B9)
    bpy.utils.register_class(SNA_OT_Mirror_Camera_Vertically_1Fff5)
    bpy.utils.register_class(SNA_OT_Reset_Camera_Rotation_02Dbe)
    bpy.utils.register_class(SNA_OT_Add_Empty_Without_Materials_7097F)
    bpy.utils.register_class(SNA_OT_Add_Empty_With_All_Materials_Abd31)
    bpy.utils.register_class(SNA_PT_GREASE_PENCIL_D473A)
    bpy.utils.register_class(SNA_PT_INFO_2DE4D)
    bpy.utils.register_class(SNA_OT_Nijigpen_C9163)
    bpy.utils.register_class(SNA_OT_Camera_Overscan_Fee71)
    bpy.utils.register_class(SNA_OT_My_Website_2D6Bd)
    bpy.utils.register_class(SNA_OT_Gumroad_Fe695)
    bpy.utils.register_class(SNA_OT_Link_All_Materials_A41Fe)
    bpy.utils.register_class(SNA_OT_Unlink_All_Materials_7Fc01)
    bpy.utils.register_class(SNA_OT_Delete_Material_238Fa)
    bpy.utils.register_class(SNA_OT_Add_Material_Stroke_Only_S_F198A)
    bpy.utils.register_class(SNA_OT_Add_Material_Fill_Only_F_B7E95)
    bpy.utils.register_class(SNA_OT_Add_Material_Stroke_And_Fill_B_B_For_Both_581B7)
    bpy.utils.register_class(SNA_PT_menu_7280E)
    bpy.utils.register_class(SNA_OT_Lock_View_Rotation_Enable_8929B)
    bpy.utils.register_class(SNA_OT_Lock_View_Rotation_Disable_00640)
    bpy.app.handlers.load_pre.append(load_pre_handler_AAF85)
    bpy.utils.register_class(SNA_OT_Set_To_Mp4_4Fc1E)
    bpy.utils.register_class(SNA_OT_Set_To_Mov_4C792)
    bpy.utils.register_class(SNA_OT_Set_To_Png_9C466)
    bpy.utils.register_class(SNA_OT_Render_Layer_Keyframes_Default_Ec843)
    bpy.utils.register_class(SNA_PT_RENDER_AND_EXPORT_6F5DF)
    bpy.utils.register_class(SNA_OT_Export_Xdts_457Ec)
    bpy.utils.register_class(SNA_OT_Render_Layer_Keyframes_Svg_3543E)
    bpy.utils.register_class(SNA_OT_Set_To_Tga_Fd0A3)
    bpy.utils.register_class(SNA_OT_Render_All_Keyframes__B07Bc)
    bpy.utils.register_class(SNA_OT_Rotate_Clockwise_B155B)
    bpy.utils.register_class(SNA_OT_Rotate_Counter_Clockwise_Acaed)
    bpy.utils.register_class(SNA_OT_Enable_Grease_Pencil_Opacity_D52Eb)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_02B43)
    bpy.utils.register_class(SNA_OT_Enable_Image_Mesh_Plane_Opacity_De052)
    bpy.utils.register_class(SNA_OT_Disable_Image_Mesh_Plane_Opacity_E26A2)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_697C5)
    bpy.utils.register_class(SNA_OT_Disable_Gp_Opacity_7E22B)
    bpy.utils.register_class(SNA_OT_Bring_Object_Forward_E16E7)
    bpy.utils.register_class(SNA_OT_Bring_Object_Backward_Aad11)
    bpy.utils.register_class(SNA_OT_Hide_From_List_05F1A)
    bpy.utils.register_class(SNA_PT_SELECTOR_MENU_D365D)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_D3288)
    bpy.utils.register_class(SNA_OT_Enable_Ref_Opacity_5375E)
    bpy.utils.register_class(SNA_OT_Disable_Ref_Opacity_Ddd03)
    bpy.utils.register_class(SNA_PT_SELECTOR_85546)
    bpy.utils.register_class(SNA_UL_display_collection_list_FECBF)
    bpy.utils.register_class(SNA_PT_SETTING_05F11)
    bpy.utils.register_class(SNA_OT_Camera_Action_Switch_950Fd)
    bpy.types.TIME_MT_editor_menus.append(sna_add_to_time_mt_editor_menus_DB484)
    bpy.utils.register_class(SNA_OT_Set_Start_C1539)
    bpy.utils.register_class(SNA_OT_Set_End_0B987)
    bpy.types.DOPESHEET_MT_editor_menus.append(sna_add_to_dopesheet_mt_editor_menus_4BB55)
    bpy.utils.register_class(SNA_PT_OBJECT_EC829)
    bpy.utils.register_class(SNA_PT_MATERIAL_19385)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.rotate_clockwise_b155b', 'PERIOD', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=True)
    addon_keymaps['E126D'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.rotate_counter_clockwise_acaed', 'COMMA', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=True)
    addon_keymaps['F095F'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_frame_number_filenames
    del bpy.types.Scene.sna_type_which_gp_to_renderexport
    del bpy.types.Scene.sna_show_brush_size_converter_pixel_to_meter
    del bpy.types.Scene.sna_brush_size
    del bpy.types.Scene.sna_toggle_overscan_as_well
    del bpy.types.Scene.sna_camera_action_2_name
    del bpy.types.Scene.sna_camera_action_1_name
    del bpy.types.Scene.sna_camera_action_switch
    del bpy.types.Scene.sna_rotation_shortcut
    del bpy.types.Scene.sna_opacity_default
    del bpy.types.Scene.sna_hide_set_startendfps_in_dopesheet
    del bpy.types.Scene.sna_hide_set_startendfps_in_timeline
    del bpy.types.Scene.sna_opacity_mesh
    del bpy.types.Scene.sna_opacity_ref
    del bpy.types.Scene.sna_include_mesh_objects
    del bpy.types.Scene.sna_object_list
    del bpy.types.Scene.sna_mute_camera_action
    del bpy.types.Scene.sna_hide_all
    del bpy.types.Scene.sna_hide_object
    del bpy.types.Scene.sna_hide_strokes
    del bpy.types.Scene.sna_hide_copas
    del bpy.types.Scene.sna_hide_camera
    del bpy.types.Scene.sna_hide_tools
    del bpy.types.Scene.sna_rotation_steps
    del bpy.types.Scene.sna_rotation_slider
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_2E5D2)
    bpy.utils.unregister_class(SNA_OT_Flip_X_A8E72)
    bpy.utils.unregister_class(SNA_OT_Flip_Y_8D615)
    bpy.utils.unregister_class(SNA_OT_Transform_Strokes_A04Ca)
    bpy.utils.unregister_class(SNA_OT_Split_7A0De)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_13B73)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_B3A42)
    bpy.utils.unregister_class(SNA_OT_Lasso_Cf183)
    bpy.utils.unregister_class(SNA_OT_Brush_57D3A)
    bpy.utils.unregister_class(SNA_OT_Erase_9D8E8)
    bpy.utils.unregister_class(SNA_OT_Fill_88837)
    bpy.utils.unregister_class(SNA_OT_Line_A9A17)
    bpy.utils.unregister_class(SNA_OT_Sculpt_Bbd1C)
    bpy.utils.unregister_class(SNA_OT_Gradient_6A423)
    bpy.utils.unregister_class(SNA_OT_Trim_9D5Fa)
    bpy.utils.unregister_class(SNA_OT_Draw_Camera_Guide_B1399)
    bpy.utils.unregister_class(SNA_OT_Transform_Object_Ab8D4)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_EDA18)
    bpy.utils.unregister_class(SNA_OT_Cut_50749)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_679FF)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_172E3)
    bpy.utils.unregister_class(SNA_OT_Select_Active_Camera_81Ec7)
    bpy.utils.unregister_class(SNA_OT_Mirror_Camera_Horizontally_861B9)
    bpy.utils.unregister_class(SNA_OT_Mirror_Camera_Vertically_1Fff5)
    bpy.utils.unregister_class(SNA_OT_Reset_Camera_Rotation_02Dbe)
    bpy.utils.unregister_class(SNA_OT_Add_Empty_Without_Materials_7097F)
    bpy.utils.unregister_class(SNA_OT_Add_Empty_With_All_Materials_Abd31)
    bpy.utils.unregister_class(SNA_PT_GREASE_PENCIL_D473A)
    bpy.utils.unregister_class(SNA_PT_INFO_2DE4D)
    bpy.utils.unregister_class(SNA_OT_Nijigpen_C9163)
    bpy.utils.unregister_class(SNA_OT_Camera_Overscan_Fee71)
    bpy.utils.unregister_class(SNA_OT_My_Website_2D6Bd)
    bpy.utils.unregister_class(SNA_OT_Gumroad_Fe695)
    bpy.utils.unregister_class(SNA_OT_Link_All_Materials_A41Fe)
    bpy.utils.unregister_class(SNA_OT_Unlink_All_Materials_7Fc01)
    bpy.utils.unregister_class(SNA_OT_Delete_Material_238Fa)
    bpy.utils.unregister_class(SNA_OT_Add_Material_Stroke_Only_S_F198A)
    bpy.utils.unregister_class(SNA_OT_Add_Material_Fill_Only_F_B7E95)
    bpy.utils.unregister_class(SNA_OT_Add_Material_Stroke_And_Fill_B_B_For_Both_581B7)
    bpy.utils.unregister_class(SNA_PT_menu_7280E)
    bpy.utils.unregister_class(SNA_OT_Lock_View_Rotation_Enable_8929B)
    bpy.utils.unregister_class(SNA_OT_Lock_View_Rotation_Disable_00640)
    bpy.app.handlers.load_pre.remove(load_pre_handler_AAF85)
    bpy.utils.unregister_class(SNA_OT_Set_To_Mp4_4Fc1E)
    bpy.utils.unregister_class(SNA_OT_Set_To_Mov_4C792)
    bpy.utils.unregister_class(SNA_OT_Set_To_Png_9C466)
    bpy.utils.unregister_class(SNA_OT_Render_Layer_Keyframes_Default_Ec843)
    bpy.utils.unregister_class(SNA_PT_RENDER_AND_EXPORT_6F5DF)
    bpy.utils.unregister_class(SNA_OT_Export_Xdts_457Ec)
    bpy.utils.unregister_class(SNA_OT_Render_Layer_Keyframes_Svg_3543E)
    bpy.utils.unregister_class(SNA_OT_Set_To_Tga_Fd0A3)
    bpy.utils.unregister_class(SNA_OT_Render_All_Keyframes__B07Bc)
    bpy.utils.unregister_class(SNA_OT_Rotate_Clockwise_B155B)
    bpy.utils.unregister_class(SNA_OT_Rotate_Counter_Clockwise_Acaed)
    bpy.utils.unregister_class(SNA_OT_Enable_Grease_Pencil_Opacity_D52Eb)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_02B43)
    bpy.utils.unregister_class(SNA_OT_Enable_Image_Mesh_Plane_Opacity_De052)
    bpy.utils.unregister_class(SNA_OT_Disable_Image_Mesh_Plane_Opacity_E26A2)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_697C5)
    bpy.utils.unregister_class(SNA_OT_Disable_Gp_Opacity_7E22B)
    bpy.utils.unregister_class(SNA_OT_Bring_Object_Forward_E16E7)
    bpy.utils.unregister_class(SNA_OT_Bring_Object_Backward_Aad11)
    bpy.utils.unregister_class(SNA_OT_Hide_From_List_05F1A)
    bpy.utils.unregister_class(SNA_PT_SELECTOR_MENU_D365D)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_D3288)
    bpy.utils.unregister_class(SNA_OT_Enable_Ref_Opacity_5375E)
    bpy.utils.unregister_class(SNA_OT_Disable_Ref_Opacity_Ddd03)
    bpy.utils.unregister_class(SNA_PT_SELECTOR_85546)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_FECBF)
    bpy.utils.unregister_class(SNA_PT_SETTING_05F11)
    bpy.utils.unregister_class(SNA_OT_Camera_Action_Switch_950Fd)
    bpy.types.TIME_MT_editor_menus.remove(sna_add_to_time_mt_editor_menus_DB484)
    bpy.utils.unregister_class(SNA_OT_Set_Start_C1539)
    bpy.utils.unregister_class(SNA_OT_Set_End_0B987)
    bpy.types.DOPESHEET_MT_editor_menus.remove(sna_add_to_dopesheet_mt_editor_menus_4BB55)
    bpy.utils.unregister_class(SNA_PT_OBJECT_EC829)
    bpy.utils.unregister_class(SNA_PT_MATERIAL_19385)
